/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";
import type * as alerts from "../alerts.js";
import type * as auth from "../auth.js";
import type * as http from "../http.js";
import type * as inventory from "../inventory.js";
import type * as materials from "../materials.js";
import type * as production from "../production.js";
import type * as reports from "../reports.js";
import type * as router from "../router.js";
import type * as sales from "../sales.js";

/**
 * A utility for referencing Convex functions in your app's API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
declare const fullApi: ApiFromModules<{
  alerts: typeof alerts;
  auth: typeof auth;
  http: typeof http;
  inventory: typeof inventory;
  materials: typeof materials;
  production: typeof production;
  reports: typeof reports;
  router: typeof router;
  sales: typeof sales;
}>;
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;
