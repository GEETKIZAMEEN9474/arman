import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Get alerts
export const getAlerts = query({
  args: {
    type: v.optional(v.string()),
    severity: v.optional(v.string()),
    isRead: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    let alerts = await ctx.db.query("alerts").collect();
    
    if (args.type) {
      alerts = alerts.filter(a => a.type === args.type);
    }
    
    if (args.severity) {
      alerts = alerts.filter(a => a.severity === args.severity);
    }
    
    if (args.isRead !== undefined) {
      alerts = alerts.filter(a => a.isRead === args.isRead);
    }
    
    return alerts.sort((a, b) => b.createdAt - a.createdAt);
  },
});

// Mark alert as read
export const markAsRead = mutation({
  args: {
    id: v.id("alerts"),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    await ctx.db.patch(args.id, {
      isRead: true,
    });
    
    return args.id;
  },
});

// Mark all alerts as read
export const markAllAsRead = mutation({
  args: {},
  handler: async (ctx) => {
    await getAuthUserId(ctx);
    
    const unreadAlerts = await ctx.db
      .query("alerts")
      .filter((q) => q.eq(q.field("isRead"), false))
      .collect();
    
    for (const alert of unreadAlerts) {
      await ctx.db.patch(alert._id, {
        isRead: true,
      });
    }
    
    return unreadAlerts.length;
  },
});

// Create alert
export const createAlert = mutation({
  args: {
    type: v.string(),
    title: v.string(),
    message: v.string(),
    severity: v.string(),
    relatedId: v.optional(v.string()),
    relatedType: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    return await ctx.db.insert("alerts", {
      ...args,
      isRead: false,
      createdAt: Date.now(),
    });
  },
});

// Delete alert
export const deleteAlert = mutation({
  args: {
    id: v.id("alerts"),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    await ctx.db.delete(args.id);
    return args.id;
  },
});

// Get unread count
export const getUnreadCount = query({
  args: {},
  handler: async (ctx) => {
    await getAuthUserId(ctx);
    
    const unreadAlerts = await ctx.db
      .query("alerts")
      .filter((q) => q.eq(q.field("isRead"), false))
      .collect();
    
    return unreadAlerts.length;
  },
});
