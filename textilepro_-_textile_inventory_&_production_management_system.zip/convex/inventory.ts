import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Get finished goods inventory
export const getFinishedGoods = query({
  args: {
    status: v.optional(v.string()),
    fabricType: v.optional(v.string()),
    qualityGrade: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    let products = await ctx.db.query("finishedGoods").collect();
    
    if (args.status) {
      products = products.filter(p => p.status === args.status);
    }
    
    if (args.fabricType) {
      products = products.filter(p => p.fabricType === args.fabricType);
    }
    
    if (args.qualityGrade) {
      products = products.filter(p => p.qualityGrade === args.qualityGrade);
    }
    
    return products.sort((a, b) => b.productionDate - a.productionDate);
  },
});

// Create finished goods entry
export const createFinishedGood = mutation({
  args: {
    productId: v.string(),
    fabricType: v.string(),
    design: v.string(),
    quantity: v.number(),
    unit: v.string(),
    qualityGrade: v.string(),
    productionDate: v.number(),
    location: v.string(),
    unitPrice: v.number(),
    batchNumber: v.string(),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    const productId = await ctx.db.insert("finishedGoods", {
      ...args,
      status: "Available",
    });

    // Record inventory movement
    await ctx.db.insert("inventoryMovements", {
      type: "IN",
      itemType: "FINISHED_GOOD",
      itemId: productId,
      quantity: args.quantity,
      unit: args.unit,
      toLocation: args.location,
      reason: "Production Complete",
      date: Date.now(),
    });

    return productId;
  },
});

// Update finished goods
export const updateFinishedGood = mutation({
  args: {
    id: v.id("finishedGoods"),
    productId: v.optional(v.string()),
    fabricType: v.optional(v.string()),
    design: v.optional(v.string()),
    quantity: v.optional(v.number()),
    unit: v.optional(v.string()),
    qualityGrade: v.optional(v.string()),
    location: v.optional(v.string()),
    unitPrice: v.optional(v.number()),
    status: v.optional(v.string()),
    batchNumber: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    const { id, ...updates } = args;
    const existing = await ctx.db.get(id);
    
    if (!existing) {
      throw new Error("Product not found");
    }

    // Track quantity changes
    if (updates.quantity !== undefined && updates.quantity !== existing.quantity) {
      const difference = updates.quantity - existing.quantity;
      await ctx.db.insert("inventoryMovements", {
        type: difference > 0 ? "IN" : "OUT",
        itemType: "FINISHED_GOOD",
        itemId: id,
        quantity: Math.abs(difference),
        unit: existing.unit,
        reason: "Stock Adjustment",
        date: Date.now(),
      });
    }

    await ctx.db.patch(id, updates);
    return id;
  },
});

// Delete finished goods
export const deleteFinishedGood = mutation({
  args: { id: v.id("finishedGoods") },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    const product = await ctx.db.get(args.id);
    if (!product) {
      throw new Error("Product not found");
    }

    // Check if product is reserved or has pending orders
    if (product.status === "Reserved") {
      throw new Error("Cannot delete reserved product");
    }

    // Record movement for deletion
    await ctx.db.insert("inventoryMovements", {
      type: "OUT",
      itemType: "FINISHED_GOOD",
      itemId: args.id,
      quantity: product.quantity,
      unit: product.unit,
      reason: "Product Deleted",
      date: Date.now(),
    });

    await ctx.db.delete(args.id);
    return args.id;
  },
});

// Get inventory movements
export const getMovements = query({
  args: {
    itemType: v.optional(v.string()),
    type: v.optional(v.string()),
    startDate: v.optional(v.number()),
    endDate: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    let movements = await ctx.db.query("inventoryMovements").collect();
    
    if (args.itemType) {
      movements = movements.filter(m => m.itemType === args.itemType);
    }
    
    if (args.type) {
      movements = movements.filter(m => m.type === args.type);
    }
    
    if (args.startDate && args.endDate) {
      movements = movements.filter(m => m.date >= args.startDate! && m.date <= args.endDate!);
    }
    
    return movements.sort((a, b) => b.date - a.date);
  },
});

// Reserve inventory for order
export const reserveInventory = mutation({
  args: {
    items: v.array(v.object({
      productId: v.id("finishedGoods"),
      quantity: v.number(),
    })),
    orderId: v.string(),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    for (const item of args.items) {
      const product = await ctx.db.get(item.productId);
      if (!product) {
        throw new Error(`Product ${item.productId} not found`);
      }
      
      if (product.quantity < item.quantity) {
        throw new Error(`Insufficient stock for ${product.fabricType}`);
      }
      
      // Update product quantity and status
      await ctx.db.patch(item.productId, {
        quantity: product.quantity - item.quantity,
        status: product.quantity - item.quantity === 0 ? "Reserved" : "Available",
      });
      
      // Record movement
      await ctx.db.insert("inventoryMovements", {
        type: "OUT",
        itemType: "FINISHED_GOOD",
        itemId: item.productId,
        quantity: item.quantity,
        unit: product.unit,
        reason: "Order Reservation",
        referenceId: args.orderId,
        date: Date.now(),
      });
    }
    
    return true;
  },
});

// Get inventory summary
export const getInventorySummary = query({
  args: {},
  handler: async (ctx) => {
    await getAuthUserId(ctx);
    
    // Materials summary
    const materials = await ctx.db.query("materials").collect();
    const materialValue = materials.reduce((sum, m) => sum + (m.quantity * m.unitPrice), 0);
    const lowStockMaterials = materials.filter(m => m.quantity <= m.reorderLevel).length;
    
    // Finished goods summary
    const finishedGoods = await ctx.db.query("finishedGoods").collect();
    const finishedGoodsValue = finishedGoods.reduce((sum, fg) => sum + (fg.quantity * fg.unitPrice), 0);
    const availableProducts = finishedGoods.filter(fg => fg.status === "Available").length;
    
    // Quality distribution
    const qualityStats = finishedGoods.reduce((acc, fg) => {
      acc[fg.qualityGrade] = (acc[fg.qualityGrade] || 0) + fg.quantity;
      return acc;
    }, {} as Record<string, number>);
    
    return {
      materials: {
        totalItems: materials.length,
        totalValue: materialValue,
        lowStockItems: lowStockMaterials,
      },
      finishedGoods: {
        totalItems: finishedGoods.length,
        totalValue: finishedGoodsValue,
        availableItems: availableProducts,
        qualityStats,
      },
    };
  },
});

// Search finished goods
export const searchFinishedGoods = query({
  args: {
    query: v.string(),
    qualityGrade: v.optional(v.string()),
    status: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    let searchQuery = ctx.db
      .query("finishedGoods")
      .withSearchIndex("search_products", (q) => {
        let search = q.search("fabricType", args.query);
        if (args.qualityGrade) {
          search = search.eq("qualityGrade", args.qualityGrade);
        }
        if (args.status) {
          search = search.eq("status", args.status);
        }
        return search;
      });
    
    return await searchQuery.take(50);
  },
});
