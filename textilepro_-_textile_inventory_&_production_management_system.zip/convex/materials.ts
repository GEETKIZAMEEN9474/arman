import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Get all materials with optional filtering
export const list = query({
  args: {
    category: v.optional(v.string()),
    lowStock: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    let materials = await ctx.db.query("materials").collect();
    
    if (args.category) {
      materials = materials.filter(m => m.category === args.category);
    }
    
    if (args.lowStock) {
      materials = materials.filter(m => m.quantity <= m.reorderLevel);
    }
    
    return materials.sort((a, b) => b.lastUpdated - a.lastUpdated);
  },
});

// Get material by ID
export const get = query({
  args: { id: v.id("materials") },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    return await ctx.db.get(args.id);
  },
});

// Create new material
export const create = mutation({
  args: {
    name: v.string(),
    category: v.string(),
    quantity: v.number(),
    unit: v.string(),
    reorderLevel: v.number(),
    unitPrice: v.number(),
    supplierId: v.optional(v.id("suppliers")),
    location: v.optional(v.string()),
    batchNumber: v.optional(v.string()),
    expiryDate: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    const materialId = await ctx.db.insert("materials", {
      ...args,
      lastUpdated: Date.now(),
    });

    // Create inventory movement record
    await ctx.db.insert("inventoryMovements", {
      type: "IN",
      itemType: "MATERIAL",
      itemId: materialId,
      quantity: args.quantity,
      unit: args.unit,
      toLocation: args.location || "Main Warehouse",
      reason: "Initial Stock",
      date: Date.now(),
    });

    return materialId;
  },
});

// Update material
export const update = mutation({
  args: {
    id: v.id("materials"),
    name: v.optional(v.string()),
    category: v.optional(v.string()),
    quantity: v.optional(v.number()),
    unit: v.optional(v.string()),
    reorderLevel: v.optional(v.number()),
    unitPrice: v.optional(v.number()),
    supplierId: v.optional(v.id("suppliers")),
    location: v.optional(v.string()),
    batchNumber: v.optional(v.string()),
    expiryDate: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    const { id, ...updates } = args;
    const existing = await ctx.db.get(id);
    
    if (!existing) {
      throw new Error("Material not found");
    }

    // Track quantity changes
    if (updates.quantity !== undefined && updates.quantity !== existing.quantity) {
      const difference = updates.quantity - existing.quantity;
      await ctx.db.insert("inventoryMovements", {
        type: difference > 0 ? "IN" : "OUT",
        itemType: "MATERIAL",
        itemId: id,
        quantity: Math.abs(difference),
        unit: existing.unit,
        reason: "Stock Adjustment",
        date: Date.now(),
      });
    }

    await ctx.db.patch(id, {
      ...updates,
      lastUpdated: Date.now(),
    });

    return id;
  },
});

// Delete material
export const remove = mutation({
  args: { id: v.id("materials") },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    await ctx.db.delete(args.id);
  },
});

// Search materials
export const search = query({
  args: {
    query: v.string(),
    category: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    const results = await ctx.db
      .query("materials")
      .withSearchIndex("search_materials", (q) => {
        let search = q.search("name", args.query);
        if (args.category) {
          search = search.eq("category", args.category);
        }
        return search;
      })
      .take(50);
    
    return results;
  },
});

// Get low stock materials
export const getLowStock = query({
  args: {},
  handler: async (ctx) => {
    await getAuthUserId(ctx);
    
    const materials = await ctx.db.query("materials").collect();
    return materials.filter(m => m.quantity <= m.reorderLevel);
  },
});

// Update stock quantity
export const updateStock = mutation({
  args: {
    id: v.id("materials"),
    quantity: v.number(),
    type: v.string(), // IN, OUT
    reason: v.string(),
    referenceId: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    const material = await ctx.db.get(args.id);
    if (!material) {
      throw new Error("Material not found");
    }

    const newQuantity = args.type === "IN" 
      ? material.quantity + args.quantity
      : material.quantity - args.quantity;

    if (newQuantity < 0) {
      throw new Error("Insufficient stock");
    }

    await ctx.db.patch(args.id, {
      quantity: newQuantity,
      lastUpdated: Date.now(),
    });

    // Record inventory movement
    await ctx.db.insert("inventoryMovements", {
      type: args.type,
      itemType: "MATERIAL",
      itemId: args.id,
      quantity: args.quantity,
      unit: material.unit,
      reason: args.reason,
      referenceId: args.referenceId,
      date: Date.now(),
    });

    // Check for low stock alert
    if (newQuantity <= material.reorderLevel) {
      await ctx.db.insert("alerts", {
        type: "LOW_STOCK",
        title: "Low Stock Alert",
        message: `${material.name} is running low. Current stock: ${newQuantity} ${material.unit}`,
        severity: "High",
        isRead: false,
        createdAt: Date.now(),
        relatedId: args.id,
        relatedType: "material",
      });
    }

    return newQuantity;
  },
});

// Get material categories
export const getCategories = query({
  args: {},
  handler: async (ctx) => {
    await getAuthUserId(ctx);
    
    const materials = await ctx.db.query("materials").collect();
    const categories = [...new Set(materials.map(m => m.category))];
    return categories.sort();
  },
});
