import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Get all looms
export const getLooms = query({
  args: {
    status: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    let looms = await ctx.db.query("looms").collect();
    
    if (args.status) {
      looms = looms.filter(l => l.status === args.status);
    }
    
    return looms.sort((a, b) => a.loomId.localeCompare(b.loomId));
  },
});

// Create loom
export const createLoom = mutation({
  args: {
    loomId: v.string(),
    model: v.string(),
    status: v.string(),
    location: v.string(),
    capacity: v.number(),
    installDate: v.number(),
    nextMaintenance: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    return await ctx.db.insert("looms", {
      ...args,
      isActive: true,
    });
  },
});

// Update loom
export const updateLoom = mutation({
  args: {
    id: v.id("looms"),
    loomId: v.optional(v.string()),
    model: v.optional(v.string()),
    status: v.optional(v.string()),
    location: v.optional(v.string()),
    capacity: v.optional(v.number()),
    lastMaintenance: v.optional(v.number()),
    nextMaintenance: v.optional(v.number()),
    isActive: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    const { id, ...updates } = args;
    await ctx.db.patch(id, updates);
    return id;
  },
});

// Get production jobs
export const getJobs = query({
  args: {
    status: v.optional(v.string()),
    loomId: v.optional(v.id("looms")),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    let jobs = await ctx.db.query("productionJobs").collect();
    
    if (args.status) {
      jobs = jobs.filter(j => j.status === args.status);
    }
    
    if (args.loomId) {
      jobs = jobs.filter(j => j.loomId === args.loomId);
    }
    
    // Get loom and worker details
    const jobsWithDetails = await Promise.all(
      jobs.map(async (job) => {
        const loom = await ctx.db.get(job.loomId);
        const worker = job.workerId ? await ctx.db.get(job.workerId) : null;
        return {
          ...job,
          loom,
          worker,
        };
      })
    );
    
    return jobsWithDetails.sort((a, b) => b.startDate - a.startDate);
  },
});

// Create production job
export const createJob = mutation({
  args: {
    jobId: v.string(),
    fabricType: v.string(),
    design: v.string(),
    targetQuantity: v.number(),
    unit: v.string(),
    loomId: v.id("looms"),
    workerId: v.optional(v.id("workers")),
    startDate: v.number(),
    endDate: v.optional(v.number()),
    priority: v.string(),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    return await ctx.db.insert("productionJobs", {
      ...args,
      producedQuantity: 0,
      status: "Pending",
    });
  },
});

// Update production job
export const updateJob = mutation({
  args: {
    id: v.id("productionJobs"),
    fabricType: v.optional(v.string()),
    design: v.optional(v.string()),
    targetQuantity: v.optional(v.number()),
    producedQuantity: v.optional(v.number()),
    loomId: v.optional(v.id("looms")),
    workerId: v.optional(v.id("workers")),
    endDate: v.optional(v.number()),
    status: v.optional(v.string()),
    priority: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    const { id, ...updates } = args;
    await ctx.db.patch(id, updates);
    return id;
  },
});

// Add production log
export const addProductionLog = mutation({
  args: {
    jobId: v.id("productionJobs"),
    loomId: v.id("looms"),
    workerId: v.optional(v.id("workers")),
    date: v.number(),
    shift: v.string(),
    metersProduced: v.number(),
    defects: v.number(),
    downtime: v.number(),
    downtimeReason: v.optional(v.string()),
    qualityGrade: v.string(),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    // Create production log
    const logId = await ctx.db.insert("productionLogs", args);
    
    // Update job's produced quantity
    const job = await ctx.db.get(args.jobId);
    if (job) {
      const newProducedQuantity = job.producedQuantity + args.metersProduced;
      const updates: any = { producedQuantity: newProducedQuantity };
      
      // Check if job is completed
      if (newProducedQuantity >= job.targetQuantity) {
        updates.status = "Completed";
        updates.endDate = Date.now();
        
        // Create finished goods entry
        await ctx.db.insert("finishedGoods", {
          productId: `FG-${job.jobId}-${Date.now()}`,
          fabricType: job.fabricType,
          design: job.design,
          quantity: args.metersProduced,
          unit: job.unit,
          qualityGrade: args.qualityGrade,
          productionDate: args.date,
          location: "Production Floor",
          unitPrice: 0, // To be updated later
          status: "Available",
          batchNumber: job.jobId,
        });
      } else if (job.status === "Pending") {
        updates.status = "In Progress";
      }
      
      await ctx.db.patch(args.jobId, updates);
    }
    
    return logId;
  },
});

// Get production logs
export const getProductionLogs = query({
  args: {
    jobId: v.optional(v.id("productionJobs")),
    loomId: v.optional(v.id("looms")),
    startDate: v.optional(v.number()),
    endDate: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    let logs = await ctx.db.query("productionLogs").collect();
    
    if (args.jobId) {
      logs = logs.filter(l => l.jobId === args.jobId);
    }
    
    if (args.loomId) {
      logs = logs.filter(l => l.loomId === args.loomId);
    }
    
    if (args.startDate && args.endDate) {
      logs = logs.filter(l => l.date >= args.startDate! && l.date <= args.endDate!);
    }
    
    // Get related data
    const logsWithDetails = await Promise.all(
      logs.map(async (log) => {
        const job = await ctx.db.get(log.jobId);
        const loom = await ctx.db.get(log.loomId);
        const worker = log.workerId ? await ctx.db.get(log.workerId) : null;
        return {
          ...log,
          job,
          loom,
          worker,
        };
      })
    );
    
    return logsWithDetails.sort((a, b) => b.date - a.date);
  },
});

// Get production dashboard data
export const getDashboardData = query({
  args: {},
  handler: async (ctx) => {
    await getAuthUserId(ctx);
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayStart = today.getTime();
    const todayEnd = todayStart + 24 * 60 * 60 * 1000;
    
    // Get today's production
    const todayLogs = await ctx.db
      .query("productionLogs")
      .filter((q) => q.and(
        q.gte(q.field("date"), todayStart),
        q.lt(q.field("date"), todayEnd)
      ))
      .collect();
    
    const todayProduction = todayLogs.reduce((sum, log) => sum + log.metersProduced, 0);
    const todayDefects = todayLogs.reduce((sum, log) => sum + log.defects, 0);
    const todayDowntime = todayLogs.reduce((sum, log) => sum + log.downtime, 0);
    
    // Get active jobs
    const activeJobs = await ctx.db
      .query("productionJobs")
      .filter((q) => q.eq(q.field("status"), "In Progress"))
      .collect();
    
    // Get loom status
    const looms = await ctx.db.query("looms").collect();
    const loomStats = {
      total: looms.length,
      active: looms.filter(l => l.status === "Active").length,
      maintenance: looms.filter(l => l.status === "Maintenance").length,
      idle: looms.filter(l => l.status === "Idle").length,
      breakdown: looms.filter(l => l.status === "Breakdown").length,
    };
    
    // Get efficiency (last 7 days)
    const weekAgo = todayStart - 7 * 24 * 60 * 60 * 1000;
    const weekLogs = await ctx.db
      .query("productionLogs")
      .filter((q) => q.gte(q.field("date"), weekAgo))
      .collect();
    
    const weeklyProduction = weekLogs.reduce((sum, log) => sum + log.metersProduced, 0);
    const weeklyTarget = activeJobs.reduce((sum, job) => sum + job.targetQuantity, 0);
    const efficiency = weeklyTarget > 0 ? (weeklyProduction / weeklyTarget) * 100 : 0;
    
    return {
      todayProduction,
      todayDefects,
      todayDowntime,
      activeJobs: activeJobs.length,
      loomStats,
      efficiency: Math.round(efficiency),
      weeklyProduction,
    };
  },
});

// Delete loom
export const deleteLoom = mutation({
  args: { id: v.id("looms") },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    const loom = await ctx.db.get(args.id);
    if (!loom) {
      throw new Error("Loom not found");
    }

    // Check if loom has active jobs
    const activeJobs = await ctx.db.query("productionJobs")
      .filter((q) => q.eq(q.field("loomId"), args.id))
      .collect();
    
    const pendingJobs = activeJobs.filter(j => j.status === "In Progress" || j.status === "Pending");
    if (pendingJobs.length > 0) {
      throw new Error("Cannot delete loom with active jobs");
    }

    await ctx.db.delete(args.id);
    return args.id;
  },
});

// Delete production job
export const deleteJob = mutation({
  args: { id: v.id("productionJobs") },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    const job = await ctx.db.get(args.id);
    if (!job) {
      throw new Error("Job not found");
    }

    // Check if job is completed
    if (job.status === "Completed") {
      throw new Error("Cannot delete completed job");
    }

    await ctx.db.delete(args.id);
    return args.id;
  },
});
