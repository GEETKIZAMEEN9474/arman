import { query } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Production Reports
export const getProductionReport = query({
  args: {
    startDate: v.optional(v.number()),
    endDate: v.optional(v.number()),
    loomId: v.optional(v.id("looms")),
    shift: v.optional(v.string()),
    qualityGrade: v.optional(v.string()),
    reportType: v.string(), // "summary", "loom-wise", "shift-wise", "quality-wise"
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    let logs = await ctx.db.query("productionLogs").collect();
    
    // Apply filters
    if (args.startDate && args.endDate) {
      logs = logs.filter(log => log.date >= args.startDate! && log.date <= args.endDate!);
    }
    
    if (args.loomId) {
      logs = logs.filter(log => log.loomId === args.loomId);
    }
    
    if (args.shift) {
      logs = logs.filter(log => log.shift === args.shift);
    }
    
    if (args.qualityGrade) {
      logs = logs.filter(log => log.qualityGrade === args.qualityGrade);
    }
    
    // Get related data
    const logsWithDetails = await Promise.all(
      logs.map(async (log) => {
        const job = await ctx.db.get(log.jobId);
        const loom = await ctx.db.get(log.loomId);
        const worker = log.workerId ? await ctx.db.get(log.workerId) : null;
        return { ...log, job, loom, worker };
      })
    );
    
    // Generate report based on type
    switch (args.reportType) {
      case "summary":
        return generateProductionSummary(logsWithDetails);
      case "loom-wise":
        return generateLoomWiseReport(logsWithDetails);
      case "shift-wise":
        return generateShiftWiseReport(logsWithDetails);
      case "quality-wise":
        return generateQualityWiseReport(logsWithDetails);
      default:
        return { data: logsWithDetails, summary: generateProductionSummary(logsWithDetails) };
    }
  },
});

// Inventory Reports
export const getInventoryReport = query({
  args: {
    category: v.optional(v.string()),
    location: v.optional(v.string()),
    lowStockOnly: v.optional(v.boolean()),
    reportType: v.string(), // "materials", "finished-goods", "movements", "low-stock"
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    switch (args.reportType) {
      case "materials":
        return await generateMaterialsReport(ctx, args);
      case "finished-goods":
        return await generateFinishedGoodsReport(ctx, args);
      case "movements":
        return await generateMovementsReport(ctx, args);
      case "low-stock":
        return await generateLowStockReport(ctx, args);
      default:
        return await generateMaterialsReport(ctx, args);
    }
  },
});

// Sales Reports
export const getSalesReport = query({
  args: {
    startDate: v.optional(v.number()),
    endDate: v.optional(v.number()),
    customerId: v.optional(v.id("customers")),
    status: v.optional(v.string()),
    reportType: v.string(), // "summary", "customer-wise", "product-wise", "region-wise"
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    let orders = await ctx.db.query("salesOrders").collect();
    
    // Apply filters
    if (args.startDate && args.endDate) {
      orders = orders.filter(order => order.orderDate >= args.startDate! && order.orderDate <= args.endDate!);
    }
    
    if (args.customerId) {
      orders = orders.filter(order => order.customerId === args.customerId);
    }
    
    if (args.status) {
      orders = orders.filter(order => order.status === args.status);
    }
    
    // Get related data
    const ordersWithDetails = await Promise.all(
      orders.map(async (order) => {
        const customer = await ctx.db.get(order.customerId);
        return { ...order, customer };
      })
    );
    
    // Generate report based on type
    switch (args.reportType) {
      case "summary":
        return generateSalesSummary(ordersWithDetails);
      case "customer-wise":
        return generateCustomerWiseReport(ordersWithDetails);
      case "product-wise":
        return generateProductWiseReport(ordersWithDetails);
      case "region-wise":
        return generateRegionWiseReport(ordersWithDetails);
      default:
        return { data: ordersWithDetails, summary: generateSalesSummary(ordersWithDetails) };
    }
  },
});

// Quality Control Reports
export const getQualityReport = query({
  args: {
    startDate: v.optional(v.number()),
    endDate: v.optional(v.number()),
    qualityGrade: v.optional(v.string()),
    reportType: v.string(), // "defects", "quality-trends", "rejection-analysis"
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    let logs = await ctx.db.query("productionLogs").collect();
    
    // Apply filters
    if (args.startDate && args.endDate) {
      logs = logs.filter(log => log.date >= args.startDate! && log.date <= args.endDate!);
    }
    
    if (args.qualityGrade) {
      logs = logs.filter(log => log.qualityGrade === args.qualityGrade);
    }
    
    // Get related data
    const logsWithDetails = await Promise.all(
      logs.map(async (log) => {
        const job = await ctx.db.get(log.jobId);
        const loom = await ctx.db.get(log.loomId);
        return { ...log, job, loom };
      })
    );
    
    // Generate report based on type
    switch (args.reportType) {
      case "defects":
        return generateDefectsReport(logsWithDetails);
      case "quality-trends":
        return generateQualityTrendsReport(logsWithDetails);
      case "rejection-analysis":
        return generateRejectionAnalysisReport(logsWithDetails);
      default:
        return generateDefectsReport(logsWithDetails);
    }
  },
});

// Combined Reports
export const getCombinedReport = query({
  args: {
    startDate: v.optional(v.number()),
    endDate: v.optional(v.number()),
    reportType: v.string(), // "production-sales", "inventory-usage", "cost-revenue"
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    switch (args.reportType) {
      case "production-sales":
        return await generateProductionSalesReport(ctx, args);
      case "inventory-usage":
        return await generateInventoryUsageReport(ctx, args);
      case "cost-revenue":
        return await generateCostRevenueReport(ctx, args);
      default:
        return await generateProductionSalesReport(ctx, args);
    }
  },
});

// Helper functions for report generation
function generateProductionSummary(logs: any[]) {
  const totalProduction = logs.reduce((sum, log) => sum + log.metersProduced, 0);
  const totalDefects = logs.reduce((sum, log) => sum + log.defects, 0);
  const totalDowntime = logs.reduce((sum, log) => sum + log.downtime, 0);
  
  const qualityDistribution = logs.reduce((acc, log) => {
    acc[log.qualityGrade] = (acc[log.qualityGrade] || 0) + log.metersProduced;
    return acc;
  }, {} as Record<string, number>);
  
  const shiftDistribution = logs.reduce((acc, log) => {
    acc[log.shift] = (acc[log.shift] || 0) + log.metersProduced;
    return acc;
  }, {} as Record<string, number>);
  
  return {
    totalProduction,
    totalDefects,
    totalDowntime,
    defectRate: totalProduction > 0 ? (totalDefects / totalProduction) * 100 : 0,
    qualityDistribution,
    shiftDistribution,
    totalLogs: logs.length,
  };
}

function generateLoomWiseReport(logs: any[]) {
  const loomData = logs.reduce((acc, log) => {
    const loomId = log.loom?.loomId || "Unknown";
    if (!acc[loomId]) {
      acc[loomId] = {
        loomId,
        model: log.loom?.model || "Unknown",
        totalProduction: 0,
        totalDefects: 0,
        totalDowntime: 0,
        logs: 0,
      };
    }
    acc[loomId].totalProduction += log.metersProduced;
    acc[loomId].totalDefects += log.defects;
    acc[loomId].totalDowntime += log.downtime;
    acc[loomId].logs += 1;
    return acc;
  }, {} as Record<string, any>);
  
  return Object.values(loomData).map((loom: any) => ({
    ...loom,
    efficiency: loom.totalDowntime > 0 ? ((loom.totalProduction / (loom.totalProduction + loom.totalDowntime)) * 100) : 100,
    defectRate: loom.totalProduction > 0 ? (loom.totalDefects / loom.totalProduction) * 100 : 0,
  }));
}

function generateShiftWiseReport(logs: any[]) {
  const shiftData = logs.reduce((acc, log) => {
    if (!acc[log.shift]) {
      acc[log.shift] = {
        shift: log.shift,
        totalProduction: 0,
        totalDefects: 0,
        totalDowntime: 0,
        logs: 0,
      };
    }
    acc[log.shift].totalProduction += log.metersProduced;
    acc[log.shift].totalDefects += log.defects;
    acc[log.shift].totalDowntime += log.downtime;
    acc[log.shift].logs += 1;
    return acc;
  }, {} as Record<string, any>);
  
  return Object.values(shiftData);
}

function generateQualityWiseReport(logs: any[]) {
  const qualityData = logs.reduce((acc, log) => {
    if (!acc[log.qualityGrade]) {
      acc[log.qualityGrade] = {
        grade: log.qualityGrade,
        totalProduction: 0,
        totalDefects: 0,
        logs: 0,
      };
    }
    acc[log.qualityGrade].totalProduction += log.metersProduced;
    acc[log.qualityGrade].totalDefects += log.defects;
    acc[log.qualityGrade].logs += 1;
    return acc;
  }, {} as Record<string, any>);
  
  return Object.values(qualityData);
}

async function generateMaterialsReport(ctx: any, args: any) {
  let materials = await ctx.db.query("materials").collect();
  
  if (args.category) {
    materials = materials.filter((m: any) => m.category === args.category);
  }
  
  if (args.location) {
    materials = materials.filter((m: any) => m.location === args.location);
  }
  
  if (args.lowStockOnly) {
    materials = materials.filter((m: any) => m.quantity <= m.reorderLevel);
  }
  
  const summary = {
    totalItems: materials.length,
    totalValue: materials.reduce((sum: number, m: any) => sum + (m.quantity * m.unitPrice), 0),
    lowStockItems: materials.filter((m: any) => m.quantity <= m.reorderLevel).length,
    categoryBreakdown: materials.reduce((acc: any, m: any) => {
      acc[m.category] = (acc[m.category] || 0) + 1;
      return acc;
    }, {}),
  };
  
  return { data: materials, summary };
}

async function generateFinishedGoodsReport(ctx: any, args: any) {
  let products = await ctx.db.query("finishedGoods").collect();
  
  const summary = {
    totalItems: products.length,
    totalValue: products.reduce((sum: number, p: any) => sum + (p.quantity * p.unitPrice), 0),
    statusBreakdown: products.reduce((acc: any, p: any) => {
      acc[p.status] = (acc[p.status] || 0) + 1;
      return acc;
    }, {}),
    qualityBreakdown: products.reduce((acc: any, p: any) => {
      acc[p.qualityGrade] = (acc[p.qualityGrade] || 0) + p.quantity;
      return acc;
    }, {}),
  };
  
  return { data: products, summary };
}

async function generateMovementsReport(ctx: any, args: any) {
  const movements = await ctx.db.query("inventoryMovements").collect();
  
  const summary = {
    totalMovements: movements.length,
    inMovements: movements.filter((m: any) => m.type === "IN").length,
    outMovements: movements.filter((m: any) => m.type === "OUT").length,
    typeBreakdown: movements.reduce((acc: any, m: any) => {
      acc[m.type] = (acc[m.type] || 0) + 1;
      return acc;
    }, {}),
  };
  
  return { data: movements.sort((a: any, b: any) => b.date - a.date), summary };
}

async function generateLowStockReport(ctx: any, args: any) {
  const materials = await ctx.db.query("materials").collect();
  const lowStockMaterials = materials.filter((m: any) => m.quantity <= m.reorderLevel);
  
  const summary = {
    totalLowStock: lowStockMaterials.length,
    criticalItems: lowStockMaterials.filter((m: any) => m.quantity <= m.reorderLevel * 0.5).length,
    totalValue: lowStockMaterials.reduce((sum: number, m: any) => sum + (m.quantity * m.unitPrice), 0),
  };
  
  return { data: lowStockMaterials, summary };
}

function generateSalesSummary(orders: any[]) {
  const totalRevenue = orders.reduce((sum, order) => sum + order.totalAmount, 0);
  const totalOrders = orders.length;
  
  const statusBreakdown = orders.reduce((acc, order) => {
    acc[order.status] = (acc[order.status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);
  
  const customerBreakdown = orders.reduce((acc, order) => {
    const customerName = order.customer?.name || "Unknown";
    acc[customerName] = (acc[customerName] || 0) + order.totalAmount;
    return acc;
  }, {} as Record<string, number>);
  
  return {
    totalRevenue,
    totalOrders,
    averageOrderValue: totalOrders > 0 ? totalRevenue / totalOrders : 0,
    statusBreakdown,
    customerBreakdown,
  };
}

function generateCustomerWiseReport(orders: any[]) {
  const customerData = orders.reduce((acc, order) => {
    const customerId = order.customer?._id || "unknown";
    const customerName = order.customer?.name || "Unknown";
    
    if (!acc[customerId]) {
      acc[customerId] = {
        customerId,
        customerName,
        totalOrders: 0,
        totalRevenue: 0,
        city: order.customer?.city || "Unknown",
      };
    }
    
    acc[customerId].totalOrders += 1;
    acc[customerId].totalRevenue += order.totalAmount;
    return acc;
  }, {} as Record<string, any>);
  
  return Object.values(customerData).sort((a: any, b: any) => b.totalRevenue - a.totalRevenue);
}

function generateProductWiseReport(orders: any[]) {
  const productData: Record<string, any> = {};
  
  orders.forEach(order => {
    order.items?.forEach((item: any) => {
      const productId = item.productId || "unknown";
      if (!productData[productId]) {
        productData[productId] = {
          productId,
          totalQuantity: 0,
          totalRevenue: 0,
          orders: 0,
        };
      }
      productData[productId].totalQuantity += item.quantity;
      productData[productId].totalRevenue += item.totalPrice;
      productData[productId].orders += 1;
    });
  });
  
  return Object.values(productData).sort((a: any, b: any) => b.totalRevenue - a.totalRevenue);
}

function generateRegionWiseReport(orders: any[]) {
  const regionData = orders.reduce((acc, order) => {
    const region = order.customer?.state || "Unknown";
    
    if (!acc[region]) {
      acc[region] = {
        region,
        totalOrders: 0,
        totalRevenue: 0,
        customers: new Set(),
      };
    }
    
    acc[region].totalOrders += 1;
    acc[region].totalRevenue += order.totalAmount;
    acc[region].customers.add(order.customer?._id);
    return acc;
  }, {} as Record<string, any>);
  
  return Object.values(regionData).map((region: any) => ({
    ...region,
    uniqueCustomers: region.customers.size,
    customers: undefined, // Remove Set from response
  })).sort((a: any, b: any) => b.totalRevenue - a.totalRevenue);
}

function generateDefectsReport(logs: any[]) {
  const totalDefects = logs.reduce((sum, log) => sum + log.defects, 0);
  const totalProduction = logs.reduce((sum, log) => sum + log.metersProduced, 0);
  
  const defectsByGrade = logs.reduce((acc, log) => {
    acc[log.qualityGrade] = (acc[log.qualityGrade] || 0) + log.defects;
    return acc;
  }, {} as Record<string, number>);
  
  const defectsByLoom = logs.reduce((acc, log) => {
    const loomId = log.loom?.loomId || "Unknown";
    acc[loomId] = (acc[loomId] || 0) + log.defects;
    return acc;
  }, {} as Record<string, number>);
  
  return {
    totalDefects,
    totalProduction,
    overallDefectRate: totalProduction > 0 ? (totalDefects / totalProduction) * 100 : 0,
    defectsByGrade,
    defectsByLoom,
    data: logs.filter(log => log.defects > 0),
  };
}

function generateQualityTrendsReport(logs: any[]) {
  // Group by date and calculate quality metrics
  const dailyQuality = logs.reduce((acc, log) => {
    const date = new Date(log.date).toDateString();
    if (!acc[date]) {
      acc[date] = {
        date,
        totalProduction: 0,
        totalDefects: 0,
        gradeA: 0,
        gradeB: 0,
        gradeC: 0,
        reject: 0,
      };
    }
    
    acc[date].totalProduction += log.metersProduced;
    acc[date].totalDefects += log.defects;
    acc[date][`grade${log.qualityGrade}`] = (acc[date][`grade${log.qualityGrade}`] || 0) + log.metersProduced;
    
    return acc;
  }, {} as Record<string, any>);
  
  return Object.values(dailyQuality).map((day: any) => ({
    ...day,
    defectRate: day.totalProduction > 0 ? (day.totalDefects / day.totalProduction) * 100 : 0,
    qualityScore: calculateQualityScore(day),
  }));
}

function generateRejectionAnalysisReport(logs: any[]) {
  const rejectedLogs = logs.filter(log => log.qualityGrade === "Reject");
  const totalRejected = rejectedLogs.reduce((sum, log) => sum + log.metersProduced, 0);
  const totalProduction = logs.reduce((sum, log) => sum + log.metersProduced, 0);
  
  const rejectionByLoom = rejectedLogs.reduce((acc, log) => {
    const loomId = log.loom?.loomId || "Unknown";
    acc[loomId] = (acc[loomId] || 0) + log.metersProduced;
    return acc;
  }, {} as Record<string, number>);
  
  const rejectionByShift = rejectedLogs.reduce((acc, log) => {
    acc[log.shift] = (acc[log.shift] || 0) + log.metersProduced;
    return acc;
  }, {} as Record<string, number>);
  
  return {
    totalRejected,
    totalProduction,
    rejectionRate: totalProduction > 0 ? (totalRejected / totalProduction) * 100 : 0,
    rejectionByLoom,
    rejectionByShift,
    data: rejectedLogs,
  };
}

async function generateProductionSalesReport(ctx: any, args: any) {
  // Get production data
  let logs = await ctx.db.query("productionLogs").collect();
  if (args.startDate && args.endDate) {
    logs = logs.filter(log => log.date >= args.startDate! && log.date <= args.endDate!);
  }
  
  // Get sales data
  let orders = await ctx.db.query("salesOrders").collect();
  if (args.startDate && args.endDate) {
    orders = orders.filter(order => order.orderDate >= args.startDate! && order.orderDate <= args.endDate!);
  }
  
  const productionSummary = generateProductionSummary(logs);
  const salesSummary = generateSalesSummary(orders);
  
  return {
    production: productionSummary,
    sales: salesSummary,
    comparison: {
      productionToSalesRatio: salesSummary.totalRevenue > 0 ? productionSummary.totalProduction / salesSummary.totalRevenue : 0,
      efficiency: productionSummary.totalProduction > 0 ? (salesSummary.totalOrders / productionSummary.totalProduction) * 100 : 0,
    },
  };
}

async function generateInventoryUsageReport(ctx: any, args: any) {
  // Get inventory movements
  let movements = await ctx.db.query("inventoryMovements").collect();
  if (args.startDate && args.endDate) {
    movements = movements.filter(movement => movement.date >= args.startDate! && movement.date <= args.endDate!);
  }
  
  // Get production data
  let logs = await ctx.db.query("productionLogs").collect();
  if (args.startDate && args.endDate) {
    logs = logs.filter(log => log.date >= args.startDate! && log.date <= args.endDate!);
  }
  
  const materialUsage = movements
    .filter(m => m.type === "OUT" && m.itemType === "MATERIAL")
    .reduce((sum, m) => sum + m.quantity, 0);
  
  const productionOutput = logs.reduce((sum, log) => sum + log.metersProduced, 0);
  
  return {
    materialUsage,
    productionOutput,
    usageEfficiency: materialUsage > 0 ? (productionOutput / materialUsage) * 100 : 0,
    movements: movements.length,
    productionLogs: logs.length,
  };
}

async function generateCostRevenueReport(ctx: any, args: any) {
  // Get materials for cost calculation
  const materials = await ctx.db.query("materials").collect();
  const totalMaterialCost = materials.reduce((sum, m) => sum + (m.quantity * m.unitPrice), 0);
  
  // Get sales for revenue calculation
  let orders = await ctx.db.query("salesOrders").collect();
  if (args.startDate && args.endDate) {
    orders = orders.filter(order => order.orderDate >= args.startDate! && order.orderDate <= args.endDate!);
  }
  
  const totalRevenue = orders.reduce((sum, order) => sum + order.totalAmount, 0);
  
  return {
    totalCost: totalMaterialCost,
    totalRevenue,
    grossProfit: totalRevenue - totalMaterialCost,
    profitMargin: totalRevenue > 0 ? ((totalRevenue - totalMaterialCost) / totalRevenue) * 100 : 0,
  };
}

function calculateQualityScore(day: any) {
  const total = day.gradeA + day.gradeB + day.gradeC + day.reject;
  if (total === 0) return 0;
  
  return ((day.gradeA * 4 + day.gradeB * 3 + day.gradeC * 2 + day.reject * 1) / total / 4) * 100;
}
