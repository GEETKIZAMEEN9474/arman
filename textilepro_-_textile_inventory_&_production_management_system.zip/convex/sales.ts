import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Get customers
export const getCustomers = query({
  args: {},
  handler: async (ctx) => {
    await getAuthUserId(ctx);
    return await ctx.db.query("customers").collect();
  },
});

// Create customer
export const createCustomer = mutation({
  args: {
    customerId: v.string(),
    name: v.string(),
    contactPerson: v.string(),
    phone: v.string(),
    email: v.string(),
    address: v.string(),
    city: v.string(),
    state: v.string(),
    pincode: v.string(),
    gstNumber: v.optional(v.string()),
    creditLimit: v.number(),
    paymentTerms: v.string(),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    return await ctx.db.insert("customers", {
      ...args,
      isActive: true,
    });
  },
});

// Update customer
export const updateCustomer = mutation({
  args: {
    id: v.id("customers"),
    customerId: v.optional(v.string()),
    name: v.optional(v.string()),
    contactPerson: v.optional(v.string()),
    phone: v.optional(v.string()),
    email: v.optional(v.string()),
    address: v.optional(v.string()),
    city: v.optional(v.string()),
    state: v.optional(v.string()),
    pincode: v.optional(v.string()),
    gstNumber: v.optional(v.string()),
    creditLimit: v.optional(v.number()),
    paymentTerms: v.optional(v.string()),
    isActive: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    const { id, ...updates } = args;
    const existing = await ctx.db.get(id);
    
    if (!existing) {
      throw new Error("Customer not found");
    }

    await ctx.db.patch(id, updates);
    return id;
  },
});

// Delete customer
export const deleteCustomer = mutation({
  args: { id: v.id("customers") },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    const customer = await ctx.db.get(args.id);
    if (!customer) {
      throw new Error("Customer not found");
    }

    // Check if customer has pending orders
    const orders = await ctx.db.query("salesOrders")
      .filter((q) => q.eq(q.field("customerId"), args.id))
      .collect();
    
    const pendingOrders = orders.filter(o => o.status === "Pending" || o.status === "Confirmed");
    if (pendingOrders.length > 0) {
      throw new Error("Cannot delete customer with pending orders");
    }

    await ctx.db.delete(args.id);
    return args.id;
  },
});

// Get sales orders
export const getOrders = query({
  args: {
    customerId: v.optional(v.id("customers")),
    status: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    let orders = await ctx.db.query("salesOrders").collect();
    
    if (args.customerId) {
      orders = orders.filter(o => o.customerId === args.customerId);
    }
    
    if (args.status) {
      orders = orders.filter(o => o.status === args.status);
    }
    
    // Get customer details
    const ordersWithCustomers = await Promise.all(
      orders.map(async (order) => {
        const customer = await ctx.db.get(order.customerId);
        return { ...order, customer };
      })
    );
    
    return ordersWithCustomers.sort((a, b) => b.orderDate - a.orderDate);
  },
});

// Create sales order
export const createOrder = mutation({
  args: {
    orderId: v.string(),
    customerId: v.id("customers"),
    orderDate: v.number(),
    deliveryDate: v.number(),
    items: v.array(v.object({
      productId: v.id("finishedGoods"),
      quantity: v.number(),
      unitPrice: v.number(),
      totalPrice: v.number(),
    })),
    totalAmount: v.number(),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    // Check inventory availability
    for (const item of args.items) {
      const product = await ctx.db.get(item.productId);
      if (!product) {
        throw new Error(`Product not found: ${item.productId}`);
      }
      if (product.quantity < item.quantity) {
        throw new Error(`Insufficient stock for ${product.fabricType}`);
      }
    }
    
    const orderId = await ctx.db.insert("salesOrders", {
      ...args,
      status: "Pending",
      paymentStatus: "Pending",
    });
    
    return orderId;
  },
});

// Update order status
export const updateOrderStatus = mutation({
  args: {
    id: v.id("salesOrders"),
    status: v.string(),
    paymentStatus: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    const { id, ...updates } = args;
    await ctx.db.patch(id, updates);
    
    // If confirmed, reserve inventory
    if (args.status === "Confirmed") {
      const order = await ctx.db.get(id);
      if (order) {
        // Reserve inventory logic would go here
        // This is handled in the inventory module
      }
    }
    
    return id;
  },
});

// Get dispatches
export const getDispatches = query({
  args: {
    status: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    let dispatches = await ctx.db.query("dispatches").collect();
    
    if (args.status) {
      dispatches = dispatches.filter(d => d.status === args.status);
    }
    
    // Get order and customer details
    const dispatchesWithDetails = await Promise.all(
      dispatches.map(async (dispatch) => {
        const order = await ctx.db.get(dispatch.orderId);
        const customer = await ctx.db.get(dispatch.customerId);
        return { ...dispatch, order, customer };
      })
    );
    
    return dispatchesWithDetails.sort((a, b) => b.dispatchDate - a.dispatchDate);
  },
});

// Create dispatch
export const createDispatch = mutation({
  args: {
    dispatchId: v.string(),
    orderId: v.id("salesOrders"),
    customerId: v.id("customers"),
    dispatchDate: v.number(),
    transportMode: v.string(),
    vehicleNumber: v.optional(v.string()),
    driverName: v.optional(v.string()),
    driverPhone: v.optional(v.string()),
    destination: v.string(),
    items: v.array(v.object({
      productId: v.id("finishedGoods"),
      quantity: v.number(),
      weight: v.number(),
    })),
    totalWeight: v.number(),
    freight: v.number(),
    trackingNumber: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    const dispatchId = await ctx.db.insert("dispatches", {
      ...args,
      status: "Dispatched",
    });
    
    // Update order status
    await ctx.db.patch(args.orderId, {
      status: "Dispatched",
    });
    
    // Update finished goods status
    for (const item of args.items) {
      await ctx.db.patch(item.productId, {
        status: "Dispatched",
      });
      
      // Record inventory movement
      await ctx.db.insert("inventoryMovements", {
        type: "OUT",
        itemType: "FINISHED_GOOD",
        itemId: item.productId,
        quantity: item.quantity,
        unit: "meters", // Default unit
        reason: "Dispatch",
        referenceId: dispatchId,
        date: Date.now(),
      });
    }
    
    return dispatchId;
  },
});

// Update dispatch status
export const updateDispatchStatus = mutation({
  args: {
    id: v.id("dispatches"),
    status: v.string(),
    deliveryDate: v.optional(v.number()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    const { id, ...updates } = args;
    await ctx.db.patch(id, updates);
    
    // If delivered, update order status
    if (args.status === "Delivered") {
      const dispatch = await ctx.db.get(id);
      if (dispatch) {
        await ctx.db.patch(dispatch.orderId, {
          status: "Delivered",
        });
      }
    }
    
    return id;
  },
});

// Get sales dashboard data
export const getSalesDashboard = query({
  args: {},
  handler: async (ctx) => {
    await getAuthUserId(ctx);
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayStart = today.getTime();
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1).getTime();
    
    // Get orders
    const allOrders = await ctx.db.query("salesOrders").collect();
    const todayOrders = allOrders.filter(o => o.orderDate >= todayStart);
    const monthOrders = allOrders.filter(o => o.orderDate >= monthStart);
    
    // Calculate totals
    const todayRevenue = todayOrders.reduce((sum, o) => sum + o.totalAmount, 0);
    const monthRevenue = monthOrders.reduce((sum, o) => sum + o.totalAmount, 0);
    
    // Get pending orders
    const pendingOrders = allOrders.filter(o => o.status === "Pending").length;
    
    // Get dispatches
    const dispatches = await ctx.db.query("dispatches").collect();
    const pendingDispatches = dispatches.filter(d => d.status === "Dispatched").length;
    
    // Get customers
    const customers = await ctx.db.query("customers").collect();
    const activeCustomers = customers.filter(c => c.isActive).length;
    
    return {
      todayOrders: todayOrders.length,
      todayRevenue,
      monthRevenue,
      pendingOrders,
      pendingDispatches,
      activeCustomers,
    };
  },
});

// Search customers
export const searchCustomers = query({
  args: {
    query: v.string(),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    return await ctx.db
      .query("customers")
      .withSearchIndex("search_customers", (q) => 
        q.search("name", args.query)
      )
      .take(20);
  },
});

// Update order
export const updateOrder = mutation({
  args: {
    id: v.id("salesOrders"),
    orderId: v.optional(v.string()),
    customerId: v.optional(v.id("customers")),
    orderDate: v.optional(v.number()),
    deliveryDate: v.optional(v.number()),
    totalAmount: v.optional(v.number()),
    status: v.optional(v.string()),
    paymentStatus: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    const { id, ...updates } = args;
    const existing = await ctx.db.get(id);
    
    if (!existing) {
      throw new Error("Order not found");
    }

    await ctx.db.patch(id, updates);
    return id;
  },
});

// Delete order
export const deleteOrder = mutation({
  args: { id: v.id("salesOrders") },
  handler: async (ctx, args) => {
    await getAuthUserId(ctx);
    
    const order = await ctx.db.get(args.id);
    if (!order) {
      throw new Error("Order not found");
    }

    // Check if order is already dispatched
    if (order.status === "Dispatched" || order.status === "Delivered") {
      throw new Error("Cannot delete dispatched or delivered order");
    }

    await ctx.db.delete(args.id);
    return args.id;
  },
});
