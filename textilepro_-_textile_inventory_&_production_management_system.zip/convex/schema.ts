import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  // Raw Materials
  materials: defineTable({
    name: v.string(),
    category: v.string(), // Yarn, Dyes, Threads, Warp, Weft, Fabric Rolls
    quantity: v.number(),
    unit: v.string(), // kg, meters, rolls, pieces
    reorderLevel: v.number(),
    unitPrice: v.number(),
    supplierId: v.optional(v.id("suppliers")),
    location: v.optional(v.string()),
    batchNumber: v.optional(v.string()),
    expiryDate: v.optional(v.number()),
    lastUpdated: v.number(),
  })
    .index("by_category", ["category"])
    .index("by_reorder", ["reorderLevel"])
    .searchIndex("search_materials", {
      searchField: "name",
      filterFields: ["category"]
    }),

  // Suppliers
  suppliers: defineTable({
    name: v.string(),
    contactPerson: v.string(),
    phone: v.string(),
    email: v.string(),
    address: v.string(),
    materials: v.array(v.string()),
    isActive: v.boolean(),
  })
    .searchIndex("search_suppliers", {
      searchField: "name"
    }),

  // Loom Machines
  looms: defineTable({
    loomId: v.string(),
    model: v.string(),
    status: v.string(), // Active, Maintenance, Idle, Breakdown
    location: v.string(),
    capacity: v.number(), // meters per hour
    installDate: v.number(),
    lastMaintenance: v.optional(v.number()),
    nextMaintenance: v.optional(v.number()),
    isActive: v.boolean(),
  })
    .index("by_status", ["status"])
    .index("by_location", ["location"]),

  // Production Jobs
  productionJobs: defineTable({
    jobId: v.string(),
    fabricType: v.string(),
    design: v.string(),
    targetQuantity: v.number(),
    producedQuantity: v.number(),
    unit: v.string(),
    loomId: v.id("looms"),
    workerId: v.optional(v.id("workers")),
    startDate: v.number(),
    endDate: v.optional(v.number()),
    status: v.string(), // Pending, In Progress, Completed, Cancelled
    priority: v.string(), // High, Medium, Low
    notes: v.optional(v.string()),
  })
    .index("by_status", ["status"])
    .index("by_loom", ["loomId"])
    .index("by_date", ["startDate"]),

  // Production Logs
  productionLogs: defineTable({
    jobId: v.id("productionJobs"),
    loomId: v.id("looms"),
    workerId: v.optional(v.id("workers")),
    date: v.number(),
    shift: v.string(), // Morning, Afternoon, Night
    metersProduced: v.number(),
    defects: v.number(),
    downtime: v.number(), // minutes
    downtimeReason: v.optional(v.string()),
    qualityGrade: v.string(), // A, B, C, Reject
    notes: v.optional(v.string()),
  })
    .index("by_job", ["jobId"])
    .index("by_loom", ["loomId"])
    .index("by_date", ["date"]),

  // Workers
  workers: defineTable({
    employeeId: v.string(),
    name: v.string(),
    phone: v.string(),
    email: v.optional(v.string()),
    department: v.string(), // Weaving, Quality, Maintenance
    shift: v.string(),
    skillLevel: v.string(), // Beginner, Intermediate, Expert
    hourlyRate: v.number(),
    joinDate: v.number(),
    isActive: v.boolean(),
  })
    .index("by_department", ["department"])
    .index("by_shift", ["shift"])
    .searchIndex("search_workers", {
      searchField: "name",
      filterFields: ["department"]
    }),

  // Finished Goods Inventory
  finishedGoods: defineTable({
    productId: v.string(),
    fabricType: v.string(),
    design: v.string(),
    quantity: v.number(),
    unit: v.string(),
    qualityGrade: v.string(),
    productionDate: v.number(),
    location: v.string(),
    unitPrice: v.number(),
    status: v.string(), // Available, Reserved, Dispatched
    batchNumber: v.string(),
  })
    .index("by_status", ["status"])
    .index("by_fabric_type", ["fabricType"])
    .index("by_quality", ["qualityGrade"])
    .searchIndex("search_products", {
      searchField: "fabricType",
      filterFields: ["qualityGrade", "status"]
    }),

  // Customers
  customers: defineTable({
    customerId: v.string(),
    name: v.string(),
    contactPerson: v.string(),
    phone: v.string(),
    email: v.string(),
    address: v.string(),
    city: v.string(),
    state: v.string(),
    pincode: v.string(),
    gstNumber: v.optional(v.string()),
    creditLimit: v.number(),
    paymentTerms: v.string(),
    isActive: v.boolean(),
  })
    .searchIndex("search_customers", {
      searchField: "name"
    }),

  // Sales Orders
  salesOrders: defineTable({
    orderId: v.string(),
    customerId: v.id("customers"),
    orderDate: v.number(),
    deliveryDate: v.number(),
    items: v.array(v.object({
      productId: v.id("finishedGoods"),
      quantity: v.number(),
      unitPrice: v.number(),
      totalPrice: v.number(),
    })),
    totalAmount: v.number(),
    status: v.string(), // Pending, Confirmed, In Production, Ready, Dispatched, Delivered
    paymentStatus: v.string(), // Pending, Partial, Paid
    notes: v.optional(v.string()),
  })
    .index("by_customer", ["customerId"])
    .index("by_status", ["status"])
    .index("by_date", ["orderDate"]),

  // Dispatch Records
  dispatches: defineTable({
    dispatchId: v.string(),
    orderId: v.id("salesOrders"),
    customerId: v.id("customers"),
    dispatchDate: v.number(),
    transportMode: v.string(), // Road, Rail, Air, Sea
    vehicleNumber: v.optional(v.string()),
    driverName: v.optional(v.string()),
    driverPhone: v.optional(v.string()),
    destination: v.string(),
    items: v.array(v.object({
      productId: v.id("finishedGoods"),
      quantity: v.number(),
      weight: v.number(),
    })),
    totalWeight: v.number(),
    freight: v.number(),
    status: v.string(), // Dispatched, In Transit, Delivered
    trackingNumber: v.optional(v.string()),
    deliveryDate: v.optional(v.number()),
    notes: v.optional(v.string()),
  })
    .index("by_order", ["orderId"])
    .index("by_status", ["status"])
    .index("by_date", ["dispatchDate"]),

  // Inventory Movements
  inventoryMovements: defineTable({
    type: v.string(), // IN, OUT, TRANSFER, ADJUSTMENT
    itemType: v.string(), // MATERIAL, FINISHED_GOOD
    itemId: v.string(), // Reference to material or finished good
    quantity: v.number(),
    unit: v.string(),
    fromLocation: v.optional(v.string()),
    toLocation: v.optional(v.string()),
    reason: v.string(),
    referenceId: v.optional(v.string()), // Order ID, Job ID, etc.
    date: v.number(),
    userId: v.optional(v.id("users")),
    notes: v.optional(v.string()),
  })
    .index("by_type", ["type"])
    .index("by_item", ["itemId"])
    .index("by_date", ["date"]),

  // Quality Control
  qualityChecks: defineTable({
    checkId: v.string(),
    itemType: v.string(), // MATERIAL, FINISHED_GOOD
    itemId: v.string(),
    batchNumber: v.string(),
    checkDate: v.number(),
    checkerId: v.id("workers"),
    parameters: v.array(v.object({
      parameter: v.string(),
      expectedValue: v.string(),
      actualValue: v.string(),
      status: v.string(), // Pass, Fail
    })),
    overallGrade: v.string(), // A, B, C, Reject
    defects: v.array(v.string()),
    remarks: v.optional(v.string()),
    images: v.optional(v.array(v.id("_storage"))),
  })
    .index("by_item", ["itemId"])
    .index("by_date", ["checkDate"])
    .index("by_grade", ["overallGrade"]),

  // Alerts
  alerts: defineTable({
    type: v.string(), // LOW_STOCK, MAINTENANCE_DUE, QUALITY_ISSUE, DELIVERY_DELAY
    title: v.string(),
    message: v.string(),
    severity: v.string(), // Low, Medium, High, Critical
    isRead: v.boolean(),
    createdAt: v.number(),
    relatedId: v.optional(v.string()),
    relatedType: v.optional(v.string()),
  })
    .index("by_type", ["type"])
    .index("by_severity", ["severity"])
    .index("by_read", ["isRead"])
    .index("by_date", ["createdAt"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
