import { useEffect, useRef } from "react";

interface ChartProps {
  type: "line" | "bar" | "doughnut" | "pie";
  data: any;
  options?: any;
}

export default function Chart({ type, data, options = {} }: ChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<any>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    // Simple chart implementation using Canvas API
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    if (type === "doughnut" && data.datasets?.[0]?.data) {
      drawDoughnutChart(ctx, data, canvas.width, canvas.height);
    }
  }, [type, data]);

  const drawDoughnutChart = (ctx: CanvasRenderingContext2D, data: any, width: number, height: number) => {
    const centerX = width / 2;
    const centerY = height / 2;
    const radius = Math.min(width, height) / 3;
    const innerRadius = radius * 0.6;

    const dataset = data.datasets[0];
    const total = dataset.data.reduce((sum: number, value: number) => sum + value, 0);
    
    let currentAngle = -Math.PI / 2;

    dataset.data.forEach((value: number, index: number) => {
      const sliceAngle = (value / total) * 2 * Math.PI;
      
      // Draw slice
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius, currentAngle, currentAngle + sliceAngle);
      ctx.arc(centerX, centerY, innerRadius, currentAngle + sliceAngle, currentAngle, true);
      ctx.closePath();
      
      ctx.fillStyle = dataset.backgroundColor[index];
      ctx.fill();
      
      currentAngle += sliceAngle;
    });

    // Draw labels
    if (data.labels) {
      ctx.fillStyle = "#374151";
      ctx.font = "12px sans-serif";
      ctx.textAlign = "center";
      
      data.labels.forEach((label: string, index: number) => {
        const y = 20 + index * 20;
        ctx.fillStyle = dataset.backgroundColor[index];
        ctx.fillRect(20, y - 8, 12, 12);
        
        ctx.fillStyle = "#374151";
        ctx.textAlign = "left";
        ctx.fillText(`${label}: ${dataset.data[index]}`, 40, y + 2);
      });
    }
  };

  return (
    <div className="relative">
      <canvas
        ref={canvasRef}
        width={400}
        height={300}
        className="max-w-full h-auto"
      />
    </div>
  );
}
