import { useState } from "react";
import Modal from "./Modal";

interface EditDialogProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  data: any;
  fields: Array<{
    key: string;
    label: string;
    type: "text" | "number" | "email" | "tel" | "date" | "select" | "textarea";
    required?: boolean;
    options?: Array<{ value: string; label: string }>;
  }>;
  onSave: (data: any) => Promise<void>;
  loading?: boolean;
}

export default function EditDialog({
  isOpen,
  onClose,
  title,
  data,
  fields,
  onSave,
  loading = false,
}: EditDialogProps) {
  const [formData, setFormData] = useState(data || {});

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await onSave(formData);
      onClose();
    } catch (error) {
      console.error("Save failed:", error);
    }
  };

  const handleChange = (key: string, value: any) => {
    setFormData((prev: any) => ({ ...prev, [key]: value }));
  };

  const renderField = (field: any) => {
    const value = formData[field.key] || "";

    switch (field.type) {
      case "select":
        return (
          <select
            required={field.required}
            value={value}
            onChange={(e) => handleChange(field.key, e.target.value)}
            className="w-full border border-gray-300 rounded-md px-3 py-2"
          >
            <option value="">Select {field.label}</option>
            {field.options?.map((option: any) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        );
      case "textarea":
        return (
          <textarea
            required={field.required}
            rows={3}
            value={value}
            onChange={(e) => handleChange(field.key, e.target.value)}
            className="w-full border border-gray-300 rounded-md px-3 py-2"
          />
        );
      case "number":
        return (
          <input
            type="number"
            required={field.required}
            min="0"
            step="0.01"
            value={value}
            onChange={(e) => handleChange(field.key, parseFloat(e.target.value) || 0)}
            className="w-full border border-gray-300 rounded-md px-3 py-2"
          />
        );
      case "date":
        return (
          <input
            type="date"
            required={field.required}
            value={typeof value === "number" ? new Date(value).toISOString().split('T')[0] : value}
            onChange={(e) => handleChange(field.key, e.target.value)}
            className="w-full border border-gray-300 rounded-md px-3 py-2"
          />
        );
      default:
        return (
          <input
            type={field.type}
            required={field.required}
            value={value}
            onChange={(e) => handleChange(field.key, e.target.value)}
            className="w-full border border-gray-300 rounded-md px-3 py-2"
          />
        );
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={title} size="lg">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {fields.map((field) => (
            <div key={field.key} className={field.type === "textarea" ? "md:col-span-2" : ""}>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {field.label} {field.required && "*"}
              </label>
              {renderField(field)}
            </div>
          ))}
        </div>

        <div className="flex justify-end space-x-3 pt-4">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-gray-700 border border-gray-300 rounded-md hover:bg-gray-50"
            disabled={loading}
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
            disabled={loading}
          >
            {loading ? "Saving..." : "Save Changes"}
          </button>
        </div>
      </form>
    </Modal>
  );
}
