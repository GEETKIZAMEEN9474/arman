import Chart from "./Chart";

interface ReportChartProps {
  data: any;
  type: "bar" | "line" | "pie" | "doughnut";
  title?: string;
  height?: number;
}

export default function ReportChart({ data, type, title, height = 300 }: ReportChartProps) {
  if (!data) {
    return (
      <div className="bg-white rounded-lg shadow p-6">
        <div className="animate-pulse">
          <div className="h-4 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow p-6">
      {title && <h3 className="text-lg font-semibold mb-4">{title}</h3>}
      <div style={{ height: `${height}px` }}>
        <Chart type={type} data={data} />
      </div>
    </div>
  );
}
