import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import StatsCard from "../components/StatsCard";
import Chart from "../components/Chart";

export default function Dashboard() {
  const productionData = useQuery(api.production.getDashboardData);
  const salesData = useQuery(api.sales.getSalesDashboard);
  const inventoryData = useQuery(api.inventory.getInventorySummary);
  const alerts = useQuery(api.alerts.getAlerts, { isRead: false });

  if (!productionData || !salesData || !inventoryData) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const stats = [
    {
      title: "Today's Production",
      value: `${productionData.todayProduction} m`,
      change: "+12%",
      trend: "up" as const,
      icon: "🏭",
    },
    {
      title: "Active Jobs",
      value: productionData.activeJobs.toString(),
      change: "+3",
      trend: "up" as const,
      icon: "⚙️",
    },
    {
      title: "Today's Revenue",
      value: `₹${salesData.todayRevenue.toLocaleString()}`,
      change: "+8%",
      trend: "up" as const,
      icon: "💰",
    },
    {
      title: "Pending Orders",
      value: salesData.pendingOrders.toString(),
      change: "-2",
      trend: "down" as const,
      icon: "📋",
    },
  ];

  const loomData = {
    labels: ["Active", "Maintenance", "Idle", "Breakdown"],
    datasets: [
      {
        data: [
          productionData.loomStats.active,
          productionData.loomStats.maintenance,
          productionData.loomStats.idle,
          productionData.loomStats.breakdown,
        ],
        backgroundColor: ["#10B981", "#F59E0B", "#6B7280", "#EF4444"],
      },
    ],
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <div className="text-sm text-gray-500">
          Last updated: {new Date().toLocaleString()}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <StatsCard key={index} {...stat} />
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-4">Loom Status Distribution</h3>
          <Chart type="doughnut" data={loomData} />
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-4">Production Efficiency</h3>
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-600 mb-2">
                {productionData.efficiency}%
              </div>
              <div className="text-gray-600">Weekly Efficiency</div>
              <div className="text-sm text-gray-500 mt-2">
                {productionData.weeklyProduction}m produced this week
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Alerts and Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-4">Recent Alerts</h3>
          <div className="space-y-3">
            {alerts && alerts.length > 0 ? (
              alerts.slice(0, 5).map((alert) => (
                <div
                  key={alert._id}
                  className={`p-3 rounded-lg border-l-4 ${
                    alert.severity === "Critical"
                      ? "border-red-500 bg-red-50"
                      : alert.severity === "High"
                      ? "border-orange-500 bg-orange-50"
                      : "border-yellow-500 bg-yellow-50"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-gray-900">{alert.title}</p>
                      <p className="text-sm text-gray-600">{alert.message}</p>
                    </div>
                    <span className="text-xs text-gray-500">
                      {new Date(alert.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-gray-500 text-center py-4">No recent alerts</p>
            )}
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-4">Inventory Summary</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div>
                <p className="font-medium">Raw Materials</p>
                <p className="text-sm text-gray-600">
                  {inventoryData.materials.totalItems} items
                </p>
              </div>
              <div className="text-right">
                <p className="font-bold text-green-600">
                  ₹{inventoryData.materials.totalValue.toLocaleString()}
                </p>
                {inventoryData.materials.lowStockItems > 0 && (
                  <p className="text-xs text-red-600">
                    {inventoryData.materials.lowStockItems} low stock
                  </p>
                )}
              </div>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div>
                <p className="font-medium">Finished Goods</p>
                <p className="text-sm text-gray-600">
                  {inventoryData.finishedGoods.totalItems} items
                </p>
              </div>
              <div className="text-right">
                <p className="font-bold text-green-600">
                  ₹{inventoryData.finishedGoods.totalValue.toLocaleString()}
                </p>
                <p className="text-xs text-gray-600">
                  {inventoryData.finishedGoods.availableItems} available
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
