import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import Modal from "../components/Modal";
import DataTable from "../components/DataTable";
import EditDialog from "../components/EditDialog";
import DeleteDialog from "../components/DeleteDialog";

export default function Inventory() {
  const [activeTab, setActiveTab] = useState("finished-goods");
  const [showModal, setShowModal] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [selectedItem, setSelectedItem] = useState<any>(null);

  const finishedGoods = useQuery(api.inventory.getFinishedGoods, {});
  const movements = useQuery(api.inventory.getMovements, {});
  const inventorySummary = useQuery(api.inventory.getInventorySummary);

  const createFinishedGood = useMutation(api.inventory.createFinishedGood);
  const updateFinishedGood = useMutation(api.inventory.updateFinishedGood);
  const deleteFinishedGood = useMutation(api.inventory.deleteFinishedGood);

  const [formData, setFormData] = useState({
    productId: "",
    fabricType: "",
    design: "",
    quantity: 0,
    unit: "meters",
    qualityGrade: "A",
    location: "Main Warehouse",
    unitPrice: 0,
    batchNumber: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createFinishedGood({
        ...formData,
        productionDate: Date.now(),
      });
      toast.success("Product added to inventory");
      setShowModal(false);
      resetForm();
    } catch (error) {
      toast.error("Failed to add product");
    }
  };

  const handleEdit = (item: any) => {
    setSelectedItem(item);
    setShowEditDialog(true);
  };

  const handleDelete = (item: any) => {
    setSelectedItem(item);
    setShowDeleteDialog(true);
  };

  const handleEditSave = async (data: any) => {
    try {
      await updateFinishedGood({
        id: selectedItem._id,
        ...data,
      });
      toast.success("Product updated successfully");
    } catch (error: any) {
      toast.error(error.message || "Failed to update product");
      throw error;
    }
  };

  const handleDeleteConfirm = async () => {
    try {
      await deleteFinishedGood({ id: selectedItem._id });
      toast.success("Product deleted successfully");
    } catch (error: any) {
      toast.error(error.message || "Failed to delete product");
      throw error;
    }
  };

  const resetForm = () => {
    setFormData({
      productId: "",
      fabricType: "",
      design: "",
      quantity: 0,
      unit: "meters",
      qualityGrade: "A",
      location: "Main Warehouse",
      unitPrice: 0,
      batchNumber: "",
    });
  };

  const finishedGoodsFields = [
    { key: "productId", label: "Product ID", type: "text" as const, required: true },
    { key: "fabricType", label: "Fabric Type", type: "text" as const, required: true },
    { key: "design", label: "Design", type: "text" as const, required: true },
    { key: "quantity", label: "Quantity", type: "number" as const, required: true },
    { 
      key: "unit", 
      label: "Unit", 
      type: "select" as const, 
      required: true,
      options: [
        { value: "meters", label: "Meters" },
        { value: "kg", label: "Kilograms" },
        { value: "pieces", label: "Pieces" },
        { value: "rolls", label: "Rolls" },
      ]
    },
    { 
      key: "qualityGrade", 
      label: "Quality Grade", 
      type: "select" as const, 
      required: true,
      options: [
        { value: "A", label: "Grade A" },
        { value: "B", label: "Grade B" },
        { value: "C", label: "Grade C" },
        { value: "Reject", label: "Reject" },
      ]
    },
    { key: "location", label: "Location", type: "text" as const, required: true },
    { key: "unitPrice", label: "Unit Price", type: "number" as const, required: true },
    { key: "batchNumber", label: "Batch Number", type: "text" as const, required: true },
  ];

  const finishedGoodsColumns = [
    { key: "productId", label: "Product ID" },
    { key: "fabricType", label: "Fabric Type" },
    { key: "design", label: "Design" },
    { 
      key: "quantity", 
      label: "Quantity",
      render: (value: number, row: any) => `${value} ${row.unit}`
    },
    { key: "qualityGrade", label: "Quality" },
    { 
      key: "status", 
      label: "Status",
      render: (value: string) => (
        <span className={`px-2 py-1 rounded-full text-xs ${
          value === "Available" ? "bg-green-100 text-green-800" :
          value === "Reserved" ? "bg-yellow-100 text-yellow-800" :
          "bg-red-100 text-red-800"
        }`}>
          {value}
        </span>
      )
    },
    { key: "location", label: "Location" },
    { 
      key: "unitPrice", 
      label: "Unit Price",
      render: (value: number) => `₹${value}`
    },
    {
      key: "actions",
      label: "Actions",
      render: (_: any, row: any) => (
        <div className="flex space-x-2">
          <button
            onClick={() => handleEdit(row)}
            className="text-blue-600 hover:text-blue-800 text-sm font-medium"
            title="Edit Product"
          >
            Edit
          </button>
          <button
            onClick={() => handleDelete(row)}
            className="text-red-600 hover:text-red-800 text-sm font-medium"
            title="Delete Product"
          >
            Delete
          </button>
        </div>
      ),
    },
  ];

  const movementColumns = [
    { 
      key: "date", 
      label: "Date",
      render: (value: number) => new Date(value).toLocaleDateString()
    },
    { 
      key: "type", 
      label: "Type",
      render: (value: string) => (
        <span className={`px-2 py-1 rounded-full text-xs ${
          value === "IN" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
        }`}>
          {value}
        </span>
      )
    },
    { key: "itemType", label: "Item Type" },
    { 
      key: "quantity", 
      label: "Quantity",
      render: (value: number, row: any) => `${value} ${row.unit}`
    },
    { key: "reason", label: "Reason" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Inventory Management</h1>
        <button
          onClick={() => setShowModal(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          Add Product
        </button>
      </div>

      {/* Summary Cards */}
      {inventorySummary && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-semibold mb-4">Raw Materials</h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Total Items:</span>
                <span className="font-semibold">{inventorySummary.materials.totalItems}</span>
              </div>
              <div className="flex justify-between">
                <span>Total Value:</span>
                <span className="font-semibold text-green-600">
                  ₹{inventorySummary.materials.totalValue.toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Low Stock Items:</span>
                <span className={`font-semibold ${
                  inventorySummary.materials.lowStockItems > 0 ? "text-red-600" : "text-green-600"
                }`}>
                  {inventorySummary.materials.lowStockItems}
                </span>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-semibold mb-4">Finished Goods</h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Total Items:</span>
                <span className="font-semibold">{inventorySummary.finishedGoods.totalItems}</span>
              </div>
              <div className="flex justify-between">
                <span>Total Value:</span>
                <span className="font-semibold text-green-600">
                  ₹{inventorySummary.finishedGoods.totalValue.toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Available Items:</span>
                <span className="font-semibold text-blue-600">
                  {inventorySummary.finishedGoods.availableItems}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="bg-white rounded-lg shadow">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8 px-6">
            <button
              onClick={() => setActiveTab("finished-goods")}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === "finished-goods"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Finished Goods
            </button>
            <button
              onClick={() => setActiveTab("movements")}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === "movements"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Inventory Movements
            </button>
          </nav>
        </div>

        <div className="p-6">
          {activeTab === "finished-goods" && (
            <DataTable
              data={finishedGoods || []}
              columns={finishedGoodsColumns}
              loading={!finishedGoods}
            />
          )}

          {activeTab === "movements" && (
            <DataTable
              data={movements || []}
              columns={movementColumns}
              loading={!movements}
            />
          )}
        </div>
      </div>

      {/* Add Product Modal */}
      <Modal
        isOpen={showModal}
        onClose={() => {
          setShowModal(false);
          resetForm();
        }}
        title="Add Finished Product"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Product ID *
              </label>
              <input
                type="text"
                required
                value={formData.productId}
                onChange={(e) => setFormData({ ...formData, productId: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Fabric Type *
              </label>
              <input
                type="text"
                required
                value={formData.fabricType}
                onChange={(e) => setFormData({ ...formData, fabricType: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Design *
              </label>
              <input
                type="text"
                required
                value={formData.design}
                onChange={(e) => setFormData({ ...formData, design: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Batch Number *
              </label>
              <input
                type="text"
                required
                value={formData.batchNumber}
                onChange={(e) => setFormData({ ...formData, batchNumber: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Quantity *
              </label>
              <input
                type="number"
                required
                min="0"
                step="0.01"
                value={formData.quantity}
                onChange={(e) => setFormData({ ...formData, quantity: parseFloat(e.target.value) })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Unit *
              </label>
              <select
                required
                value={formData.unit}
                onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              >
                <option value="meters">Meters</option>
                <option value="kg">Kilograms</option>
                <option value="pieces">Pieces</option>
                <option value="rolls">Rolls</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Quality Grade *
              </label>
              <select
                required
                value={formData.qualityGrade}
                onChange={(e) => setFormData({ ...formData, qualityGrade: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              >
                <option value="A">Grade A</option>
                <option value="B">Grade B</option>
                <option value="C">Grade C</option>
                <option value="Reject">Reject</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Location *
              </label>
              <input
                type="text"
                required
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Unit Price *
              </label>
              <input
                type="number"
                required
                min="0"
                step="0.01"
                value={formData.unitPrice}
                onChange={(e) => setFormData({ ...formData, unitPrice: parseFloat(e.target.value) })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={() => {
                setShowModal(false);
                resetForm();
              }}
              className="px-4 py-2 text-gray-700 border border-gray-300 rounded-md hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              Add Product
            </button>
          </div>
        </form>
      </Modal>

      {/* Edit Dialog */}
      <EditDialog
        isOpen={showEditDialog}
        onClose={() => setShowEditDialog(false)}
        title="Edit Product"
        data={selectedItem}
        fields={finishedGoodsFields}
        onSave={handleEditSave}
      />

      {/* Delete Dialog */}
      <DeleteDialog
        isOpen={showDeleteDialog}
        onClose={() => setShowDeleteDialog(false)}
        title="Delete Product"
        message={`Are you sure you want to delete product "${selectedItem?.productId}"? This action cannot be undone.`}
        onConfirm={handleDeleteConfirm}
      />
    </div>
  );
}
