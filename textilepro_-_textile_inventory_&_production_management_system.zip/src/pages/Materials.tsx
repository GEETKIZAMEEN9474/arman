import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import Modal from "../components/Modal";
import DataTable from "../components/DataTable";
import EditDialog from "../components/EditDialog";
import DeleteDialog from "../components/DeleteDialog";

export default function Materials() {
  const [showModal, setShowModal] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [selectedMaterial, setSelectedMaterial] = useState<any>(null);
  const [selectedCategory, setSelectedCategory] = useState("");
  const [showLowStock, setShowLowStock] = useState(false);

  const materials = useQuery(api.materials.list, {
    category: selectedCategory || undefined,
    lowStock: showLowStock || undefined,
  });
  const categories = useQuery(api.materials.getCategories);
  const createMaterial = useMutation(api.materials.create);
  const updateMaterial = useMutation(api.materials.update);
  const deleteMaterial = useMutation(api.materials.remove);

  const [formData, setFormData] = useState({
    name: "",
    category: "",
    quantity: 0,
    unit: "",
    reorderLevel: 0,
    unitPrice: 0,
    location: "",
    batchNumber: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createMaterial(formData);
      toast.success("Material created successfully");
      setShowModal(false);
      resetForm();
    } catch (error) {
      toast.error("Failed to save material");
    }
  };

  const handleEdit = (material: any) => {
    setSelectedMaterial(material);
    setShowEditDialog(true);
  };

  const handleDelete = (material: any) => {
    setSelectedMaterial(material);
    setShowDeleteDialog(true);
  };

  const handleEditSave = async (data: any) => {
    try {
      await updateMaterial({
        id: selectedMaterial._id,
        ...data,
      });
      toast.success("Material updated successfully");
    } catch (error: any) {
      toast.error(error.message || "Failed to update material");
      throw error;
    }
  };

  const handleDeleteConfirm = async () => {
    try {
      await deleteMaterial({ id: selectedMaterial._id });
      toast.success("Material deleted successfully");
    } catch (error: any) {
      toast.error(error.message || "Failed to delete material");
      throw error;
    }
  };

  const resetForm = () => {
    setFormData({
      name: "",
      category: "",
      quantity: 0,
      unit: "",
      reorderLevel: 0,
      unitPrice: 0,
      location: "",
      batchNumber: "",
    });
  };

  const materialFields = [
    { key: "name", label: "Name", type: "text" as const, required: true },
    { 
      key: "category", 
      label: "Category", 
      type: "select" as const, 
      required: true,
      options: [
        { value: "Yarn", label: "Yarn" },
        { value: "Dyes", label: "Dyes" },
        { value: "Threads", label: "Threads" },
        { value: "Warp", label: "Warp" },
        { value: "Weft", label: "Weft" },
        { value: "Fabric Rolls", label: "Fabric Rolls" },
      ]
    },
    { key: "quantity", label: "Quantity", type: "number" as const, required: true },
    { 
      key: "unit", 
      label: "Unit", 
      type: "select" as const, 
      required: true,
      options: [
        { value: "kg", label: "Kilograms" },
        { value: "meters", label: "Meters" },
        { value: "rolls", label: "Rolls" },
        { value: "pieces", label: "Pieces" },
        { value: "liters", label: "Liters" },
      ]
    },
    { key: "reorderLevel", label: "Reorder Level", type: "number" as const, required: true },
    { key: "unitPrice", label: "Unit Price", type: "number" as const, required: true },
    { key: "location", label: "Location", type: "text" as const },
    { key: "batchNumber", label: "Batch Number", type: "text" as const },
  ];

  const columns = [
    { key: "name", label: "Name" },
    { key: "category", label: "Category" },
    { 
      key: "quantity", 
      label: "Quantity",
      render: (value: number, row: any) => `${value} ${row.unit}`
    },
    { 
      key: "reorderLevel", 
      label: "Reorder Level",
      render: (value: number, row: any) => (
        <span className={row.quantity <= value ? "text-red-600 font-semibold" : ""}>
          {value} {row.unit}
        </span>
      )
    },
    { 
      key: "unitPrice", 
      label: "Unit Price",
      render: (value: number) => `₹${value}`
    },
    { key: "location", label: "Location" },
    {
      key: "actions",
      label: "Actions",
      render: (_: any, row: any) => (
        <div className="flex space-x-2">
          <button
            onClick={() => handleEdit(row)}
            className="text-blue-600 hover:text-blue-800 text-sm font-medium"
            title="Edit Material"
          >
            Edit
          </button>
          <button
            onClick={() => handleDelete(row)}
            className="text-red-600 hover:text-red-800 text-sm font-medium"
            title="Delete Material"
          >
            Delete
          </button>
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Raw Materials</h1>
        <button
          onClick={() => setShowModal(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          Add Material
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-lg shadow flex items-center space-x-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Category
          </label>
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="border border-gray-300 rounded-md px-3 py-2"
          >
            <option value="">All Categories</option>
            {categories?.map((category) => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
          </select>
        </div>
        
        <div className="flex items-center">
          <input
            type="checkbox"
            id="lowStock"
            checked={showLowStock}
            onChange={(e) => setShowLowStock(e.target.checked)}
            className="mr-2"
          />
          <label htmlFor="lowStock" className="text-sm font-medium text-gray-700">
            Show Low Stock Only
          </label>
        </div>
      </div>

      {/* Materials Table */}
      <div className="bg-white rounded-lg shadow">
        <DataTable
          data={materials || []}
          columns={columns}
          loading={!materials}
        />
      </div>

      {/* Add Material Modal */}
      <Modal
        isOpen={showModal}
        onClose={() => {
          setShowModal(false);
          resetForm();
        }}
        title="Add New Material"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Name *
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Category *
              </label>
              <select
                required
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              >
                <option value="">Select Category</option>
                <option value="Yarn">Yarn</option>
                <option value="Dyes">Dyes</option>
                <option value="Threads">Threads</option>
                <option value="Warp">Warp</option>
                <option value="Weft">Weft</option>
                <option value="Fabric Rolls">Fabric Rolls</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Quantity *
              </label>
              <input
                type="number"
                required
                min="0"
                step="0.01"
                value={formData.quantity}
                onChange={(e) => setFormData({ ...formData, quantity: parseFloat(e.target.value) })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Unit *
              </label>
              <select
                required
                value={formData.unit}
                onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              >
                <option value="">Select Unit</option>
                <option value="kg">Kilograms</option>
                <option value="meters">Meters</option>
                <option value="rolls">Rolls</option>
                <option value="pieces">Pieces</option>
                <option value="liters">Liters</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Reorder Level *
              </label>
              <input
                type="number"
                required
                min="0"
                step="0.01"
                value={formData.reorderLevel}
                onChange={(e) => setFormData({ ...formData, reorderLevel: parseFloat(e.target.value) })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Unit Price *
              </label>
              <input
                type="number"
                required
                min="0"
                step="0.01"
                value={formData.unitPrice}
                onChange={(e) => setFormData({ ...formData, unitPrice: parseFloat(e.target.value) })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Location
              </label>
              <input
                type="text"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Batch Number
            </label>
            <input
              type="text"
              value={formData.batchNumber}
              onChange={(e) => setFormData({ ...formData, batchNumber: e.target.value })}
              className="w-full border border-gray-300 rounded-md px-3 py-2"
            />
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={() => {
                setShowModal(false);
                resetForm();
              }}
              className="px-4 py-2 text-gray-700 border border-gray-300 rounded-md hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              Create
            </button>
          </div>
        </form>
      </Modal>

      {/* Edit Dialog */}
      <EditDialog
        isOpen={showEditDialog}
        onClose={() => setShowEditDialog(false)}
        title="Edit Material"
        data={selectedMaterial}
        fields={materialFields}
        onSave={handleEditSave}
      />

      {/* Delete Dialog */}
      <DeleteDialog
        isOpen={showDeleteDialog}
        onClose={() => setShowDeleteDialog(false)}
        title="Delete Material"
        message={`Are you sure you want to delete material "${selectedMaterial?.name}"? This action cannot be undone.`}
        onConfirm={handleDeleteConfirm}
      />
    </div>
  );
}
