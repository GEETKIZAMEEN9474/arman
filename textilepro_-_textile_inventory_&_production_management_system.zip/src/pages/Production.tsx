import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import Modal from "../components/Modal";
import DataTable from "../components/DataTable";
import EditDialog from "../components/EditDialog";
import DeleteDialog from "../components/DeleteDialog";

export default function Production() {
  const [activeTab, setActiveTab] = useState("jobs");
  const [showModal, setShowModal] = useState(false);
  const [modalType, setModalType] = useState<"loom" | "job" | "log">("job");
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [editType, setEditType] = useState<"loom" | "job" | "log">("job");

  const looms = useQuery(api.production.getLooms, {});
  const jobs = useQuery(api.production.getJobs, {});
  const productionLogs = useQuery(api.production.getProductionLogs, {});
  const dashboardData = useQuery(api.production.getDashboardData);

  const createLoom = useMutation(api.production.createLoom);
  const createJob = useMutation(api.production.createJob);
  const addProductionLog = useMutation(api.production.addProductionLog);
  const updateLoom = useMutation(api.production.updateLoom);
  const updateJob = useMutation(api.production.updateJob);
  const deleteLoom = useMutation(api.production.deleteLoom);
  const deleteJob = useMutation(api.production.deleteJob);

  const [loomForm, setLoomForm] = useState({
    loomId: "",
    model: "",
    status: "Idle",
    location: "",
    capacity: 0,
    installDate: new Date().toISOString().split('T')[0],
    nextMaintenance: new Date().toISOString().split('T')[0],
  });

  const [jobForm, setJobForm] = useState({
    jobId: "",
    fabricType: "",
    design: "",
    targetQuantity: 0,
    unit: "meters",
    loomId: "",
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date().toISOString().split('T')[0],
    priority: "Medium",
    notes: "",
  });

  const [logForm, setLogForm] = useState({
    jobId: "",
    loomId: "",
    date: new Date().toISOString().split('T')[0],
    shift: "Morning",
    metersProduced: 0,
    defects: 0,
    downtime: 0,
    downtimeReason: "",
    qualityGrade: "A",
    notes: "",
  });

  const handleLoomSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createLoom({
        ...loomForm,
        capacity: Number(loomForm.capacity),
        installDate: new Date(loomForm.installDate).getTime(),
        nextMaintenance: new Date(loomForm.nextMaintenance).getTime(),
      });
      toast.success("Loom added successfully");
      setShowModal(false);
      resetForms();
    } catch (error) {
      toast.error("Failed to add loom");
    }
  };

  const handleJobSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createJob({
        ...jobForm,
        targetQuantity: Number(jobForm.targetQuantity),
        loomId: jobForm.loomId as any,
        startDate: new Date(jobForm.startDate).getTime(),
        endDate: jobForm.endDate ? new Date(jobForm.endDate).getTime() : undefined,
      });
      toast.success("Production job created successfully");
      setShowModal(false);
      resetForms();
    } catch (error) {
      toast.error("Failed to create production job");
    }
  };

  const handleLogSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addProductionLog({
        ...logForm,
        jobId: logForm.jobId as any,
        loomId: logForm.loomId as any,
        date: new Date(logForm.date).getTime(),
        metersProduced: Number(logForm.metersProduced),
        defects: Number(logForm.defects),
        downtime: Number(logForm.downtime),
      });
      toast.success("Production log added successfully");
      setShowModal(false);
      resetForms();
    } catch (error) {
      toast.error("Failed to add production log");
    }
  };

  const resetForms = () => {
    setLoomForm({
      loomId: "",
      model: "",
      status: "Idle",
      location: "",
      capacity: 0,
      installDate: new Date().toISOString().split('T')[0],
      nextMaintenance: new Date().toISOString().split('T')[0],
    });
    setJobForm({
      jobId: "",
      fabricType: "",
      design: "",
      targetQuantity: 0,
      unit: "meters",
      loomId: "",
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date().toISOString().split('T')[0],
      priority: "Medium",
      notes: "",
    });
    setLogForm({
      jobId: "",
      loomId: "",
      date: new Date().toISOString().split('T')[0],
      shift: "Morning",
      metersProduced: 0,
      defects: 0,
      downtime: 0,
      downtimeReason: "",
      qualityGrade: "A",
      notes: "",
    });
  };

  const handleEdit = (item: any, type: "loom" | "job" | "log") => {
    setSelectedItem(item);
    setEditType(type);
    setShowEditDialog(true);
  };

  const handleDelete = (item: any, type: "loom" | "job" | "log") => {
    setSelectedItem(item);
    setEditType(type);
    setShowDeleteDialog(true);
  };

  const handleEditSave = async (data: any) => {
    try {
      if (editType === "loom") {
        await updateLoom({ id: selectedItem._id, ...data });
        toast.success("Loom updated successfully");
      } else if (editType === "job") {
        await updateJob({ id: selectedItem._id, ...data });
        toast.success("Job updated successfully");
      }
    } catch (error: any) {
      toast.error(error.message || "Failed to update");
      throw error;
    }
  };

  const handleDeleteConfirm = async () => {
    try {
      if (editType === "loom") {
        await deleteLoom({ id: selectedItem._id });
        toast.success("Loom deleted successfully");
      } else if (editType === "job") {
        await deleteJob({ id: selectedItem._id });
        toast.success("Job deleted successfully");
      }
    } catch (error: any) {
      toast.error(error.message || "Failed to delete");
      throw error;
    }
  };

  const loomColumns = [
    { key: "loomId", label: "Loom ID" },
    { key: "model", label: "Model" },
    { 
      key: "status", 
      label: "Status",
      render: (value: string) => (
        <span className={`px-2 py-1 rounded-full text-xs ${
          value === "Active" ? "bg-green-100 text-green-800" :
          value === "Maintenance" ? "bg-yellow-100 text-yellow-800" :
          value === "Breakdown" ? "bg-red-100 text-red-800" :
          "bg-gray-100 text-gray-800"
        }`}>
          {value}
        </span>
      )
    },
    { key: "location", label: "Location" },
    { 
      key: "capacity", 
      label: "Capacity",
      render: (value: number) => `${value} m/hr`
    },
    { 
      key: "installDate", 
      label: "Install Date",
      render: (value: number) => new Date(value).toLocaleDateString()
    },
    {
      key: "actions",
      label: "Actions",
      render: (_: any, row: any) => (
        <div className="flex space-x-2">
          <button
            onClick={() => handleEdit(row, "loom")}
            className="text-blue-600 hover:text-blue-800 text-sm font-medium"
            title="Edit Loom"
          >
            Edit
          </button>
          <button
            onClick={() => handleDelete(row, "loom")}
            className="text-red-600 hover:text-red-800 text-sm font-medium"
            title="Delete Loom"
          >
            Delete
          </button>
        </div>
      ),
    },
  ];

  const jobColumns = [
    { key: "jobId", label: "Job ID" },
    { key: "fabricType", label: "Fabric Type" },
    { key: "design", label: "Design" },
    { 
      key: "targetQuantity", 
      label: "Target",
      render: (value: number, row: any) => `${value} ${row.unit}`
    },
    { 
      key: "producedQuantity", 
      label: "Produced",
      render: (value: number, row: any) => `${value} ${row.unit}`
    },
    { 
      key: "loom", 
      label: "Loom",
      render: (loom: any) => loom?.loomId || "N/A"
    },
    { 
      key: "status", 
      label: "Status",
      render: (value: string) => (
        <span className={`px-2 py-1 rounded-full text-xs ${
          value === "Pending" ? "bg-yellow-100 text-yellow-800" :
          value === "In Progress" ? "bg-blue-100 text-blue-800" :
          value === "Completed" ? "bg-green-100 text-green-800" :
          "bg-red-100 text-red-800"
        }`}>
          {value}
        </span>
      )
    },
    { 
      key: "priority", 
      label: "Priority",
      render: (value: string) => (
        <span className={`px-2 py-1 rounded-full text-xs ${
          value === "High" ? "bg-red-100 text-red-800" :
          value === "Medium" ? "bg-yellow-100 text-yellow-800" :
          "bg-green-100 text-green-800"
        }`}>
          {value}
        </span>
      )
    },
    {
      key: "actions",
      label: "Actions",
      render: (_: any, row: any) => (
        <div className="flex space-x-2">
          <button
            onClick={() => handleEdit(row, "job")}
            className="text-blue-600 hover:text-blue-800 text-sm font-medium"
            title="Edit Job"
          >
            Edit
          </button>
          <button
            onClick={() => handleDelete(row, "job")}
            className="text-red-600 hover:text-red-800 text-sm font-medium"
            title="Delete Job"
          >
            Delete
          </button>
        </div>
      ),
    },
  ];

  const logColumns = [
    { 
      key: "date", 
      label: "Date",
      render: (value: number) => new Date(value).toLocaleDateString()
    },
    { key: "shift", label: "Shift" },
    { 
      key: "job", 
      label: "Job",
      render: (job: any) => job?.jobId || "N/A"
    },
    { 
      key: "loom", 
      label: "Loom",
      render: (loom: any) => loom?.loomId || "N/A"
    },
    { 
      key: "metersProduced", 
      label: "Produced",
      render: (value: number) => `${value}m`
    },
    { key: "defects", label: "Defects" },
    { 
      key: "downtime", 
      label: "Downtime",
      render: (value: number) => `${value} min`
    },
    { 
      key: "qualityGrade", 
      label: "Quality",
      render: (value: string) => (
        <span className={`px-2 py-1 rounded-full text-xs ${
          value === "A" ? "bg-green-100 text-green-800" :
          value === "B" ? "bg-blue-100 text-blue-800" :
          value === "C" ? "bg-yellow-100 text-yellow-800" :
          "bg-red-100 text-red-800"
        }`}>
          Grade {value}
        </span>
      )
    },
  ];

  const loomFields = [
    { key: "loomId", label: "Loom ID", type: "text" as const, required: true },
    { key: "model", label: "Model", type: "text" as const, required: true },
    { 
      key: "status", 
      label: "Status", 
      type: "select" as const, 
      required: true,
      options: [
        { value: "Active", label: "Active" },
        { value: "Idle", label: "Idle" },
        { value: "Maintenance", label: "Maintenance" },
        { value: "Breakdown", label: "Breakdown" },
      ]
    },
    { key: "location", label: "Location", type: "text" as const, required: true },
    { key: "capacity", label: "Capacity (m/hr)", type: "number" as const, required: true },
    { key: "installDate", label: "Install Date", type: "date" as const, required: true },
    { key: "nextMaintenance", label: "Next Maintenance", type: "date" as const },
  ];

  const jobFields = [
    { key: "jobId", label: "Job ID", type: "text" as const, required: true },
    { key: "fabricType", label: "Fabric Type", type: "text" as const, required: true },
    { key: "design", label: "Design", type: "text" as const, required: true },
    { key: "targetQuantity", label: "Target Quantity", type: "number" as const, required: true },
    { key: "notes", label: "Notes", type: "textarea" as const },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Production Management</h1>
        <div className="flex space-x-2">
          <button
            onClick={() => {
              setModalType("loom");
              setShowModal(true);
            }}
            className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors"
          >
            Add Loom
          </button>
          <button
            onClick={() => {
              setModalType("job");
              setShowModal(true);
            }}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            New Job
          </button>
          <button
            onClick={() => {
              setModalType("log");
              setShowModal(true);
            }}
            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
          >
            Add Log
          </button>
        </div>
      </div>

      {/* Dashboard Cards */}
      {dashboardData && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="text-2xl font-bold text-blue-600">{dashboardData.todayProduction}m</div>
            <div className="text-sm text-gray-600">Today's Production</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="text-2xl font-bold text-green-600">{dashboardData.activeJobs}</div>
            <div className="text-sm text-gray-600">Active Jobs</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="text-2xl font-bold text-purple-600">{dashboardData.efficiency}%</div>
            <div className="text-sm text-gray-600">Efficiency</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="text-2xl font-bold text-orange-600">{dashboardData.todayDefects}</div>
            <div className="text-sm text-gray-600">Today's Defects</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="text-2xl font-bold text-red-600">{dashboardData.todayDowntime}min</div>
            <div className="text-sm text-gray-600">Today's Downtime</div>
          </div>
        </div>
      )}

      {/* Loom Status Overview */}
      {dashboardData && (
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-4">Loom Status Overview</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{dashboardData.loomStats.active}</div>
              <div className="text-sm text-gray-600">Active</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-600">{dashboardData.loomStats.maintenance}</div>
              <div className="text-sm text-gray-600">Maintenance</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-600">{dashboardData.loomStats.idle}</div>
              <div className="text-sm text-gray-600">Idle</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">{dashboardData.loomStats.breakdown}</div>
              <div className="text-sm text-gray-600">Breakdown</div>
            </div>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="bg-white rounded-lg shadow">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8 px-6">
            <button
              onClick={() => setActiveTab("jobs")}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === "jobs"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Production Jobs
            </button>
            <button
              onClick={() => setActiveTab("looms")}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === "looms"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Looms
            </button>
            <button
              onClick={() => setActiveTab("logs")}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === "logs"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Production Logs
            </button>
          </nav>
        </div>

        <div className="p-6">
          {activeTab === "jobs" && (
            <DataTable
              data={jobs || []}
              columns={jobColumns}
              loading={!jobs}
            />
          )}

          {activeTab === "looms" && (
            <DataTable
              data={looms || []}
              columns={loomColumns}
              loading={!looms}
            />
          )}

          {activeTab === "logs" && (
            <DataTable
              data={productionLogs || []}
              columns={logColumns}
              loading={!productionLogs}
            />
          )}
        </div>
      </div>

      {/* Loom Modal */}
      <Modal
        isOpen={showModal && modalType === "loom"}
        onClose={() => {
          setShowModal(false);
          resetForms();
        }}
        title="Add New Loom"
      >
        <form onSubmit={handleLoomSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Loom ID *
              </label>
              <input
                type="text"
                required
                value={loomForm.loomId}
                onChange={(e) => setLoomForm({ ...loomForm, loomId: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Model *
              </label>
              <input
                type="text"
                required
                value={loomForm.model}
                onChange={(e) => setLoomForm({ ...loomForm, model: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Status *
              </label>
              <select
                required
                value={loomForm.status}
                onChange={(e) => setLoomForm({ ...loomForm, status: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              >
                <option value="Active">Active</option>
                <option value="Idle">Idle</option>
                <option value="Maintenance">Maintenance</option>
                <option value="Breakdown">Breakdown</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Location *
              </label>
              <input
                type="text"
                required
                value={loomForm.location}
                onChange={(e) => setLoomForm({ ...loomForm, location: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Capacity (m/hr) *
              </label>
              <input
                type="number"
                required
                min="0"
                step="0.1"
                value={loomForm.capacity}
                onChange={(e) => setLoomForm({ ...loomForm, capacity: parseFloat(e.target.value) })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Install Date *
              </label>
              <input
                type="date"
                required
                value={loomForm.installDate}
                onChange={(e) => setLoomForm({ ...loomForm, installDate: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Next Maintenance
              </label>
              <input
                type="date"
                value={loomForm.nextMaintenance}
                onChange={(e) => setLoomForm({ ...loomForm, nextMaintenance: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={() => {
                setShowModal(false);
                resetForms();
              }}
              className="px-4 py-2 text-gray-700 border border-gray-300 rounded-md hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700"
            >
              Add Loom
            </button>
          </div>
        </form>
      </Modal>

      {/* Job Modal */}
      <Modal
        isOpen={showModal && modalType === "job"}
        onClose={() => {
          setShowModal(false);
          resetForms();
        }}
        title="Create Production Job"
        size="lg"
      >
        <form onSubmit={handleJobSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Job ID *
              </label>
              <input
                type="text"
                required
                value={jobForm.jobId}
                onChange={(e) => setJobForm({ ...jobForm, jobId: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Fabric Type *
              </label>
              <input
                type="text"
                required
                value={jobForm.fabricType}
                onChange={(e) => setJobForm({ ...jobForm, fabricType: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Design *
              </label>
              <input
                type="text"
                required
                value={jobForm.design}
                onChange={(e) => setJobForm({ ...jobForm, design: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Loom *
              </label>
              <select
                required
                value={jobForm.loomId}
                onChange={(e) => setJobForm({ ...jobForm, loomId: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              >
                <option value="">Select Loom</option>
                {looms?.map((loom) => (
                  <option key={loom._id} value={loom._id}>
                    {loom.loomId} - {loom.model}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Target Quantity *
              </label>
              <input
                type="number"
                required
                min="0"
                step="0.01"
                value={jobForm.targetQuantity}
                onChange={(e) => setJobForm({ ...jobForm, targetQuantity: parseFloat(e.target.value) })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Unit *
              </label>
              <select
                required
                value={jobForm.unit}
                onChange={(e) => setJobForm({ ...jobForm, unit: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              >
                <option value="meters">Meters</option>
                <option value="kg">Kilograms</option>
                <option value="pieces">Pieces</option>
                <option value="rolls">Rolls</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Priority *
              </label>
              <select
                required
                value={jobForm.priority}
                onChange={(e) => setJobForm({ ...jobForm, priority: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              >
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Start Date *
              </label>
              <input
                type="date"
                required
                value={jobForm.startDate}
                onChange={(e) => setJobForm({ ...jobForm, startDate: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Expected End Date
              </label>
              <input
                type="date"
                value={jobForm.endDate}
                onChange={(e) => setJobForm({ ...jobForm, endDate: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Notes
            </label>
            <textarea
              rows={3}
              value={jobForm.notes}
              onChange={(e) => setJobForm({ ...jobForm, notes: e.target.value })}
              className="w-full border border-gray-300 rounded-md px-3 py-2"
            />
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={() => {
                setShowModal(false);
                resetForms();
              }}
              className="px-4 py-2 text-gray-700 border border-gray-300 rounded-md hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              Create Job
            </button>
          </div>
        </form>
      </Modal>

      {/* Production Log Modal */}
      <Modal
        isOpen={showModal && modalType === "log"}
        onClose={() => {
          setShowModal(false);
          resetForms();
        }}
        title="Add Production Log"
        size="lg"
      >
        <form onSubmit={handleLogSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Job *
              </label>
              <select
                required
                value={logForm.jobId}
                onChange={(e) => setLogForm({ ...logForm, jobId: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              >
                <option value="">Select Job</option>
                {jobs?.filter(job => job.status === "In Progress").map((job) => (
                  <option key={job._id} value={job._id}>
                    {job.jobId} - {job.fabricType}
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Loom *
              </label>
              <select
                required
                value={logForm.loomId}
                onChange={(e) => setLogForm({ ...logForm, loomId: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              >
                <option value="">Select Loom</option>
                {looms?.filter(loom => loom.status === "Active").map((loom) => (
                  <option key={loom._id} value={loom._id}>
                    {loom.loomId} - {loom.model}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Date *
              </label>
              <input
                type="date"
                required
                value={logForm.date}
                onChange={(e) => setLogForm({ ...logForm, date: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Shift *
              </label>
              <select
                required
                value={logForm.shift}
                onChange={(e) => setLogForm({ ...logForm, shift: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              >
                <option value="Morning">Morning</option>
                <option value="Afternoon">Afternoon</option>
                <option value="Night">Night</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Quality Grade *
              </label>
              <select
                required
                value={logForm.qualityGrade}
                onChange={(e) => setLogForm({ ...logForm, qualityGrade: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              >
                <option value="A">Grade A</option>
                <option value="B">Grade B</option>
                <option value="C">Grade C</option>
                <option value="Reject">Reject</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Meters Produced *
              </label>
              <input
                type="number"
                required
                min="0"
                step="0.01"
                value={logForm.metersProduced}
                onChange={(e) => setLogForm({ ...logForm, metersProduced: parseFloat(e.target.value) })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Defects
              </label>
              <input
                type="number"
                min="0"
                value={logForm.defects}
                onChange={(e) => setLogForm({ ...logForm, defects: parseInt(e.target.value) })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Downtime (minutes)
              </label>
              <input
                type="number"
                min="0"
                value={logForm.downtime}
                onChange={(e) => setLogForm({ ...logForm, downtime: parseInt(e.target.value) })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Downtime Reason
            </label>
            <input
              type="text"
              value={logForm.downtimeReason}
              onChange={(e) => setLogForm({ ...logForm, downtimeReason: e.target.value })}
              className="w-full border border-gray-300 rounded-md px-3 py-2"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Notes
            </label>
            <textarea
              rows={3}
              value={logForm.notes}
              onChange={(e) => setLogForm({ ...logForm, notes: e.target.value })}
              className="w-full border border-gray-300 rounded-md px-3 py-2"
            />
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={() => {
                setShowModal(false);
                resetForms();
              }}
              className="px-4 py-2 text-gray-700 border border-gray-300 rounded-md hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
            >
              Add Log
            </button>
          </div>
        </form>
      </Modal>

      {/* Edit Dialog */}
      <EditDialog
        isOpen={showEditDialog}
        onClose={() => setShowEditDialog(false)}
        title={`Edit ${editType === "loom" ? "Loom" : "Job"}`}
        data={selectedItem}
        fields={editType === "loom" ? loomFields : jobFields}
        onSave={handleEditSave}
      />

      {/* Delete Dialog */}
      <DeleteDialog
        isOpen={showDeleteDialog}
        onClose={() => setShowDeleteDialog(false)}
        title={`Delete ${editType === "loom" ? "Loom" : "Job"}`}
        message={`Are you sure you want to delete this ${editType}? This action cannot be undone.`}
        onConfirm={handleDeleteConfirm}
      />
    </div>
  );
}
