import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import FilterBar from "../components/FilterBar";
import ReportTable from "../components/ReportTable";
import ReportChart from "../components/ReportChart";
import ExportButtons from "../components/ExportButtons";

export default function Reports() {
  const [activeTab, setActiveTab] = useState("production");
  const [reportType, setReportType] = useState("summary");
  const [viewMode, setViewMode] = useState<"table" | "chart">("table");
  const [filters, setFilters] = useState<any>({});

  // Data queries
  const looms = useQuery(api.production.getLooms, {});
  const customers = useQuery(api.sales.getCustomers);
  const categories = useQuery(api.materials.getCategories);

  // Report data queries
  const productionReport = useQuery(
    api.reports.getProductionReport,
    activeTab === "production"
      ? {
          ...filters,
          reportType,
          startDate: filters.startDate ? new Date(filters.startDate).getTime() : undefined,
          endDate: filters.endDate ? new Date(filters.endDate).getTime() : undefined,
        }
      : "skip"
  );

  const inventoryReport = useQuery(
    api.reports.getInventoryReport,
    activeTab === "inventory"
      ? {
          ...filters,
          reportType,
        }
      : "skip"
  );

  const salesReport = useQuery(
    api.reports.getSalesReport,
    activeTab === "sales"
      ? {
          ...filters,
          reportType,
          startDate: filters.startDate ? new Date(filters.startDate).getTime() : undefined,
          endDate: filters.endDate ? new Date(filters.endDate).getTime() : undefined,
        }
      : "skip"
  );

  const qualityReport = useQuery(
    api.reports.getQualityReport,
    activeTab === "quality"
      ? {
          ...filters,
          reportType,
          startDate: filters.startDate ? new Date(filters.startDate).getTime() : undefined,
          endDate: filters.endDate ? new Date(filters.endDate).getTime() : undefined,
        }
      : "skip"
  );

  const combinedReport = useQuery(
    api.reports.getCombinedReport,
    activeTab === "combined"
      ? {
          ...filters,
          reportType,
          startDate: filters.startDate ? new Date(filters.startDate).getTime() : undefined,
          endDate: filters.endDate ? new Date(filters.endDate).getTime() : undefined,
        }
      : "skip"
  );

  const getCurrentReport = () => {
    switch (activeTab) {
      case "production":
        return productionReport;
      case "inventory":
        return inventoryReport;
      case "sales":
        return salesReport;
      case "quality":
        return qualityReport;
      case "combined":
        return combinedReport;
      default:
        return null;
    }
  };

  const getReportTypes = () => {
    switch (activeTab) {
      case "production":
        return [
          { value: "summary", label: "Production Summary" },
          { value: "loom-wise", label: "Loom-wise Report" },
          { value: "shift-wise", label: "Shift-wise Report" },
          { value: "quality-wise", label: "Quality-wise Report" },
        ];
      case "inventory":
        return [
          { value: "materials", label: "Materials Report" },
          { value: "finished-goods", label: "Finished Goods Report" },
          { value: "movements", label: "Movements Report" },
          { value: "low-stock", label: "Low Stock Report" },
        ];
      case "sales":
        return [
          { value: "summary", label: "Sales Summary" },
          { value: "customer-wise", label: "Customer-wise Report" },
          { value: "product-wise", label: "Product-wise Report" },
          { value: "region-wise", label: "Region-wise Report" },
        ];
      case "quality":
        return [
          { value: "defects", label: "Defects Report" },
          { value: "quality-trends", label: "Quality Trends" },
          { value: "rejection-analysis", label: "Rejection Analysis" },
        ];
      case "combined":
        return [
          { value: "production-sales", label: "Production vs Sales" },
          { value: "inventory-usage", label: "Inventory Usage" },
          { value: "cost-revenue", label: "Cost vs Revenue" },
        ];
      default:
        return [];
    }
  };

  const getFilterOptions = () => {
    const baseOptions = { dateRange: true };
    
    switch (activeTab) {
      case "production":
        return { ...baseOptions, loomId: true, shift: true, qualityGrade: true };
      case "inventory":
        return { ...baseOptions, category: true, location: true };
      case "sales":
        return { ...baseOptions, customerId: true, status: true };
      case "quality":
        return { ...baseOptions, qualityGrade: true };
      case "combined":
        return baseOptions;
      default:
        return baseOptions;
    }
  };

  const getTableColumns = () => {
    const report = getCurrentReport();
    if (!report || !report.data || !Array.isArray(report.data) || report.data.length === 0) {
      return [];
    }

    const firstRow = report.data[0];
    return Object.keys(firstRow).map(key => ({
      key,
      label: key.charAt(0).toUpperCase() + key.slice(1).replace(/([A-Z])/g, ' $1'),
      render: (value: any) => {
        if (typeof value === 'number') {
          if (key.includes('Date') || key.includes('date')) {
            return new Date(value).toLocaleDateString();
          }
          if (key.includes('Price') || key.includes('Amount') || key.includes('Revenue') || key.includes('Cost')) {
            return `₹${value.toLocaleString()}`;
          }
          if (key.includes('Rate') || key.includes('Percentage')) {
            return `${value.toFixed(2)}%`;
          }
          return value.toLocaleString();
        }
        if (typeof value === 'object' && value !== null) {
          return value.name || value.loomId || JSON.stringify(value);
        }
        return value;
      },
    }));
  };

  const getChartData = () => {
    const report = getCurrentReport();
    if (!report) return null;

    // Generate chart data based on report type and data
    if (activeTab === "production" && reportType === "loom-wise" && Array.isArray(report)) {
      return {
        labels: report.map((item: any) => item.loomId),
        datasets: [
          {
            label: "Production (meters)",
            data: report.map((item: any) => item.totalProduction),
            backgroundColor: "rgba(59, 130, 246, 0.5)",
            borderColor: "rgba(59, 130, 246, 1)",
            borderWidth: 1,
          },
        ],
      };
    }

    if (activeTab === "sales" && reportType === "customer-wise" && Array.isArray(report)) {
      return {
        labels: report.slice(0, 10).map((item: any) => item.customerName),
        datasets: [
          {
            label: "Revenue (₹)",
            data: report.slice(0, 10).map((item: any) => item.totalRevenue),
            backgroundColor: "rgba(16, 185, 129, 0.5)",
            borderColor: "rgba(16, 185, 129, 1)",
            borderWidth: 1,
          },
        ],
      };
    }

    if (report.summary) {
      const summary = report.summary;
      if (summary.qualityDistribution) {
        return {
          labels: Object.keys(summary.qualityDistribution),
          datasets: [
            {
              data: Object.values(summary.qualityDistribution),
              backgroundColor: [
                "rgba(16, 185, 129, 0.8)",
                "rgba(59, 130, 246, 0.8)",
                "rgba(245, 158, 11, 0.8)",
                "rgba(239, 68, 68, 0.8)",
              ],
            },
          ],
        };
      }
      
      if (summary.statusBreakdown) {
        return {
          labels: Object.keys(summary.statusBreakdown),
          datasets: [
            {
              data: Object.values(summary.statusBreakdown),
              backgroundColor: [
                "rgba(245, 158, 11, 0.8)",
                "rgba(59, 130, 246, 0.8)",
                "rgba(147, 51, 234, 0.8)",
                "rgba(16, 185, 129, 0.8)",
              ],
            },
          ],
        };
      }
    }

    return null;
  };

  const currentReport = getCurrentReport();
  const reportData = Array.isArray(currentReport) ? currentReport : currentReport?.data || [];
  const isLoading = currentReport === undefined;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Advanced Reports</h1>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <label className="text-sm font-medium text-gray-700">View:</label>
            <select
              value={viewMode}
              onChange={(e) => setViewMode(e.target.value as "table" | "chart")}
              className="border border-gray-300 rounded-md px-3 py-1 text-sm"
            >
              <option value="table">Table</option>
              <option value="chart">Chart</option>
            </select>
          </div>
          <ExportButtons
            data={reportData}
            filename={`${activeTab}_${reportType}_report`}
          />
        </div>
      </div>

      {/* Report Type Selection */}
      <div className="bg-white p-4 rounded-lg shadow">
        <div className="flex items-center space-x-4 mb-4">
          <label className="text-sm font-medium text-gray-700">Report Type:</label>
          <select
            value={reportType}
            onChange={(e) => setReportType(e.target.value)}
            className="border border-gray-300 rounded-md px-3 py-2"
          >
            {getReportTypes().map((type) => (
              <option key={type.value} value={type.value}>
                {type.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-lg shadow">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8 px-6">
            {[
              { key: "production", label: "Production Reports" },
              { key: "inventory", label: "Inventory Reports" },
              { key: "sales", label: "Sales Reports" },
              { key: "quality", label: "Quality Reports" },
              { key: "combined", label: "Combined Reports" },
            ].map((tab) => (
              <button
                key={tab.key}
                onClick={() => {
                  setActiveTab(tab.key);
                  setReportType(getReportTypes()[0]?.value || "summary");
                }}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab.key
                    ? "border-blue-500 text-blue-600"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Filters */}
      <FilterBar
        onFilterChange={setFilters}
        filterOptions={getFilterOptions()}
        looms={looms || []}
        customers={customers || []}
        categories={categories || []}
        locations={["Main Warehouse", "Secondary Warehouse", "Production Floor"]}
      />

      {/* Summary Cards */}
      {currentReport?.summary && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {Object.entries(currentReport.summary).map(([key, value]) => {
            if (typeof value === 'object') return null;
            return (
              <div key={key} className="bg-white p-6 rounded-lg shadow">
                <div className="text-2xl font-bold text-blue-600">
                  {typeof value === 'number' 
                    ? key.includes('Rate') || key.includes('Percentage') || key.includes('Margin')
                      ? `${value.toFixed(2)}%`
                      : key.includes('Revenue') || key.includes('Cost') || key.includes('Value') || key.includes('Amount')
                      ? `₹${value.toLocaleString()}`
                      : value.toLocaleString()
                    : value
                  }
                </div>
                <div className="text-sm text-gray-600">
                  {key.charAt(0).toUpperCase() + key.slice(1).replace(/([A-Z])/g, ' $1')}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Report Content */}
      <div className="space-y-6">
        {viewMode === "table" ? (
          <ReportTable
            data={reportData}
            columns={getTableColumns()}
            loading={isLoading}
            title={getReportTypes().find(t => t.value === reportType)?.label}
          />
        ) : (
          <ReportChart
            data={getChartData()}
            type={activeTab === "production" && reportType === "loom-wise" ? "bar" : "doughnut"}
            title={getReportTypes().find(t => t.value === reportType)?.label}
          />
        )}
      </div>
    </div>
  );
}
