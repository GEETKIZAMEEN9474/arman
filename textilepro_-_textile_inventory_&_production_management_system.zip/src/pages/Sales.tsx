import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import Modal from "../components/Modal";
import DataTable from "../components/DataTable";
import EditDialog from "../components/EditDialog";
import DeleteDialog from "../components/DeleteDialog";

export default function Sales() {
  const [activeTab, setActiveTab] = useState("orders");
  const [showModal, setShowModal] = useState(false);
  const [modalType, setModalType] = useState<"customer" | "order" | "dispatch">("customer");
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [editType, setEditType] = useState<"customer" | "order" | "dispatch">("customer");

  const customers = useQuery(api.sales.getCustomers);
  const orders = useQuery(api.sales.getOrders, {});
  const dispatches = useQuery(api.sales.getDispatches, {});
  const salesDashboard = useQuery(api.sales.getSalesDashboard);

  const createCustomer = useMutation(api.sales.createCustomer);
  const createOrder = useMutation(api.sales.createOrder);
  const createDispatch = useMutation(api.sales.createDispatch);
  const updateCustomer = useMutation(api.sales.updateCustomer);
  const updateOrder = useMutation(api.sales.updateOrder);
  const updateDispatch = useMutation(api.sales.updateDispatch);
  const deleteCustomer = useMutation(api.sales.deleteCustomer);
  const deleteOrder = useMutation(api.sales.deleteOrder);
  const deleteDispatch = useMutation(api.sales.deleteDispatch);

  const [customerForm, setCustomerForm] = useState({
    customerId: "",
    name: "",
    contactPerson: "",
    phone: "",
    email: "",
    address: "",
    city: "",
    state: "",
    pincode: "",
    gstNumber: "",
    creditLimit: 0,
    paymentTerms: "30 days",
  });

  const [orderForm, setOrderForm] = useState({
    orderId: "",
    customerId: "",
    orderDate: new Date().toISOString().split('T')[0],
    deliveryDate: new Date().toISOString().split('T')[0],
    items: [],
    totalAmount: 0,
    notes: "",
  });

  const handleCustomerSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createCustomer(customerForm);
      toast.success("Customer created successfully");
      setShowModal(false);
      resetForms();
    } catch (error) {
      toast.error("Failed to create customer");
    }
  };

  const resetForms = () => {
    setCustomerForm({
      customerId: "",
      name: "",
      contactPerson: "",
      phone: "",
      email: "",
      address: "",
      city: "",
      state: "",
      pincode: "",
      gstNumber: "",
      creditLimit: 0,
      paymentTerms: "30 days",
    });
    setOrderForm({
      orderId: "",
      customerId: "",
      orderDate: new Date().toISOString().split('T')[0],
      deliveryDate: new Date().toISOString().split('T')[0],
      items: [],
      totalAmount: 0,
      notes: "",
    });
  };

  const handleEdit = (item: any, type: "customer" | "order" | "dispatch") => {
    setSelectedItem(item);
    setEditType(type);
    setShowEditDialog(true);
  };

  const handleDelete = (item: any, type: "customer" | "order" | "dispatch") => {
    setSelectedItem(item);
    setEditType(type);
    setShowDeleteDialog(true);
  };

  const customerColumns = [
    { key: "customerId", label: "Customer ID" },
    { key: "name", label: "Name" },
    { key: "contactPerson", label: "Contact Person" },
    { key: "phone", label: "Phone" },
    { key: "email", label: "Email" },
    { key: "city", label: "City" },
    { 
      key: "creditLimit", 
      label: "Credit Limit",
      render: (value: number) => `₹${value.toLocaleString()}`
    },
    { key: "paymentTerms", label: "Payment Terms" },
    {
      key: "actions",
      label: "Actions",
      render: (_: any, row: any) => (
        <div className="flex space-x-2">
          <button
            onClick={() => handleEdit(row, "customer")}
            className="text-blue-600 hover:text-blue-800 text-sm font-medium"
            title="Edit Customer"
          >
            Edit
          </button>
          <button
            onClick={() => handleDelete(row, "customer")}
            className="text-red-600 hover:text-red-800 text-sm font-medium"
            title="Delete Customer"
          >
            Delete
          </button>
        </div>
      ),
    },
  ];

  const orderColumns = [
    { key: "orderId", label: "Order ID" },
    { 
      key: "customer", 
      label: "Customer",
      render: (customer: any) => customer?.name || "N/A"
    },
    { 
      key: "orderDate", 
      label: "Order Date",
      render: (value: number) => new Date(value).toLocaleDateString()
    },
    { 
      key: "deliveryDate", 
      label: "Delivery Date",
      render: (value: number) => new Date(value).toLocaleDateString()
    },
    { 
      key: "totalAmount", 
      label: "Amount",
      render: (value: number) => `₹${value.toLocaleString()}`
    },
    { 
      key: "status", 
      label: "Status",
      render: (value: string) => (
        <span className={`px-2 py-1 rounded-full text-xs ${
          value === "Pending" ? "bg-yellow-100 text-yellow-800" :
          value === "Confirmed" ? "bg-blue-100 text-blue-800" :
          value === "Dispatched" ? "bg-purple-100 text-purple-800" :
          "bg-green-100 text-green-800"
        }`}>
          {value}
        </span>
      )
    },
    { 
      key: "paymentStatus", 
      label: "Payment",
      render: (value: string) => (
        <span className={`px-2 py-1 rounded-full text-xs ${
          value === "Pending" ? "bg-red-100 text-red-800" :
          value === "Partial" ? "bg-yellow-100 text-yellow-800" :
          "bg-green-100 text-green-800"
        }`}>
          {value}
        </span>
      )
    },
    {
      key: "actions",
      label: "Actions",
      render: (_: any, row: any) => (
        <div className="flex space-x-2">
          <button
            onClick={() => handleEdit(row, "order")}
            className="text-blue-600 hover:text-blue-800 text-sm font-medium"
            title="Edit Order"
          >
            Edit
          </button>
          <button
            onClick={() => handleDelete(row, "order")}
            className="text-red-600 hover:text-red-800 text-sm font-medium"
            title="Delete Order"
          >
            Delete
          </button>
        </div>
      ),
    },
  ];

  const dispatchColumns = [
    { key: "dispatchId", label: "Dispatch ID" },
    { 
      key: "customer", 
      label: "Customer",
      render: (customer: any) => customer?.name || "N/A"
    },
    { 
      key: "dispatchDate", 
      label: "Dispatch Date",
      render: (value: number) => new Date(value).toLocaleDateString()
    },
    { key: "destination", label: "Destination" },
    { key: "transportMode", label: "Transport" },
    { 
      key: "totalWeight", 
      label: "Weight",
      render: (value: number) => `${value} kg`
    },
    { 
      key: "status", 
      label: "Status",
      render: (value: string) => (
        <span className={`px-2 py-1 rounded-full text-xs ${
          value === "Dispatched" ? "bg-blue-100 text-blue-800" :
          value === "In Transit" ? "bg-yellow-100 text-yellow-800" :
          "bg-green-100 text-green-800"
        }`}>
          {value}
        </span>
      )
    },
    {
      key: "actions",
      label: "Actions",
      render: (_: any, row: any) => (
        <div className="flex space-x-2">
          <button
            onClick={() => handleEdit(row, "dispatch")}
            className="text-blue-600 hover:text-blue-800 text-sm font-medium"
            title="Edit Dispatch"
          >
            Edit
          </button>
          <button
            onClick={() => handleDelete(row, "dispatch")}
            className="text-red-600 hover:text-red-800 text-sm font-medium"
            title="Delete Dispatch"
          >
            Delete
          </button>
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Sales Management</h1>
        <div className="flex space-x-2">
          <button
            onClick={() => {
              setModalType("customer");
              setShowModal(true);
            }}
            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
          >
            Add Customer
          </button>
          <button
            onClick={() => {
              setModalType("order");
              setShowModal(true);
            }}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            New Order
          </button>
        </div>
      </div>

      {/* Dashboard Cards */}
      {salesDashboard && (
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="text-2xl font-bold text-blue-600">{salesDashboard.todayOrders}</div>
            <div className="text-sm text-gray-600">Today's Orders</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="text-2xl font-bold text-green-600">
              ₹{salesDashboard.todayRevenue.toLocaleString()}
            </div>
            <div className="text-sm text-gray-600">Today's Revenue</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="text-2xl font-bold text-purple-600">
              ₹{salesDashboard.monthRevenue.toLocaleString()}
            </div>
            <div className="text-sm text-gray-600">Month Revenue</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="text-2xl font-bold text-orange-600">{salesDashboard.pendingOrders}</div>
            <div className="text-sm text-gray-600">Pending Orders</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="text-2xl font-bold text-red-600">{salesDashboard.pendingDispatches}</div>
            <div className="text-sm text-gray-600">Pending Dispatches</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="text-2xl font-bold text-indigo-600">{salesDashboard.activeCustomers}</div>
            <div className="text-sm text-gray-600">Active Customers</div>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="bg-white rounded-lg shadow">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8 px-6">
            <button
              onClick={() => setActiveTab("orders")}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === "orders"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Sales Orders
            </button>
            <button
              onClick={() => setActiveTab("customers")}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === "customers"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Customers
            </button>
            <button
              onClick={() => setActiveTab("dispatches")}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === "dispatches"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Dispatches
            </button>
          </nav>
        </div>

        <div className="p-6">
          {activeTab === "orders" && (
            <DataTable
              data={orders || []}
              columns={orderColumns}
              loading={!orders}
            />
          )}

          {activeTab === "customers" && (
            <DataTable
              data={customers || []}
              columns={customerColumns}
              loading={!customers}
            />
          )}

          {activeTab === "dispatches" && (
            <DataTable
              data={dispatches || []}
              columns={dispatchColumns}
              loading={!dispatches}
            />
          )}
        </div>
      </div>

      {/* Customer Modal */}
      <Modal
        isOpen={showModal && modalType === "customer"}
        onClose={() => {
          setShowModal(false);
          resetForms();
        }}
        title="Add New Customer"
        size="lg"
      >
        <form onSubmit={handleCustomerSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Customer ID *
              </label>
              <input
                type="text"
                required
                value={customerForm.customerId}
                onChange={(e) => setCustomerForm({ ...customerForm, customerId: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Company Name *
              </label>
              <input
                type="text"
                required
                value={customerForm.name}
                onChange={(e) => setCustomerForm({ ...customerForm, name: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Contact Person *
              </label>
              <input
                type="text"
                required
                value={customerForm.contactPerson}
                onChange={(e) => setCustomerForm({ ...customerForm, contactPerson: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Phone *
              </label>
              <input
                type="tel"
                required
                value={customerForm.phone}
                onChange={(e) => setCustomerForm({ ...customerForm, phone: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Email *
            </label>
            <input
              type="email"
              required
              value={customerForm.email}
              onChange={(e) => setCustomerForm({ ...customerForm, email: e.target.value })}
              className="w-full border border-gray-300 rounded-md px-3 py-2"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Address *
            </label>
            <textarea
              required
              rows={3}
              value={customerForm.address}
              onChange={(e) => setCustomerForm({ ...customerForm, address: e.target.value })}
              className="w-full border border-gray-300 rounded-md px-3 py-2"
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                City *
              </label>
              <input
                type="text"
                required
                value={customerForm.city}
                onChange={(e) => setCustomerForm({ ...customerForm, city: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                State *
              </label>
              <input
                type="text"
                required
                value={customerForm.state}
                onChange={(e) => setCustomerForm({ ...customerForm, state: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Pincode *
              </label>
              <input
                type="text"
                required
                value={customerForm.pincode}
                onChange={(e) => setCustomerForm({ ...customerForm, pincode: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                GST Number
              </label>
              <input
                type="text"
                value={customerForm.gstNumber}
                onChange={(e) => setCustomerForm({ ...customerForm, gstNumber: e.target.value })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Credit Limit *
              </label>
              <input
                type="number"
                required
                min="0"
                value={customerForm.creditLimit}
                onChange={(e) => setCustomerForm({ ...customerForm, creditLimit: parseFloat(e.target.value) })}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Payment Terms *
            </label>
            <select
              required
              value={customerForm.paymentTerms}
              onChange={(e) => setCustomerForm({ ...customerForm, paymentTerms: e.target.value })}
              className="w-full border border-gray-300 rounded-md px-3 py-2"
            >
              <option value="Cash">Cash</option>
              <option value="15 days">15 days</option>
              <option value="30 days">30 days</option>
              <option value="45 days">45 days</option>
              <option value="60 days">60 days</option>
            </select>
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={() => {
                setShowModal(false);
                resetForms();
              }}
              className="px-4 py-2 text-gray-700 border border-gray-300 rounded-md hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
            >
              Create Customer
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
